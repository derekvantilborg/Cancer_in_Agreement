# This script performs all differential anlysis on metabolomics and transcriptomics data.
# Both differential abundance/expression analysis and differential connectivity analysis through network inferring is done here

# script containing all functions
source('R Code/R_functions.R')


Metabolomics_data_sets = list.files('Data/Metabolomics', '*.rds', full.names = T)
Transcriptomics_data_sets = list.files('Data/Transcriptomics/', '*.rds', full.names = T)
Transcriptomics_mvg_data_sets = list.files('Data/Transcriptomics_most_variable_genes/', '*.rds', full.names = T)

dir.create('Data/DC')
dir.create('Data/DE')

## ---- Differential Abundance/Expression ----

# Metabolites
for (filename in Metabolomics_data_sets){
  cat('\n---- starting Diff Exp', word(filename, -1,sep='/'),'----\n\n')
  Out = Diff_exp(filename)
  saveRDS(Out, paste0('Data/DE/Diff_Exp_Metab_', word(filename, -1,sep='/')))
  }

# Genes
for (filename in Transcriptomics_data_sets){
  cat('\n---- starting Diff Exp', word(filename, -1,sep='/'),'----\n\n')
  Out = Diff_exp(filename)
  saveRDS(Out, paste0('Data/DE/Diff_Exp_Genes_', word(filename, -1,sep='/')))
  }

## ---- Differential Connectivity ----

# Metabolites
for (filename in Metabolomics_data_sets){
  cat('\n---- starting Diff Conn', word(filename, -1,sep='/'),'----\n\n')
  # Read data
  nets = readRDS(filename)
  # Infer association network
  RES = Diff.Conn.PCLRC.gmm(nets$network1, 
                            nets$network2, 
                            corr.type = 'spearman', 
                            prob.threshold = 0.95, 
                            adjust.diff = 'BH', 
                            Niter = 1000, 
                            MaxPerm = 1000, 
                            frac=0.75, 
                            rank.thr=0.3, 
                            verbose = FALSE)
  saveRDS(RES, paste0('Data/DC/Diff_Conn_Metab_', word(filename, -1,sep='/')))
}
# Genes
for (filename in Transcriptomics_mvg_data_sets){
  cat('\n---- starting Diff Conn', word(filename, -1,sep='/'),'----\n\n')
  # Read data
  nets = readRDS(filename)
  # Infer association network
  RES = Diff.Conn.PCLRC.gmm(nets$network1, 
                            nets$network2, 
                            corr.type = 'spearman', 
                            prob.threshold = 0.99, 
                            adjust.diff = 'BH', 
                            Niter = 100, 
                            MaxPerm = 100, 
                            frac=0.75, 
                            rank.thr=0.3, 
                            verbose = FALSE)
  saveRDS(RES, paste0('Data/DC/Diff_Conn_Genes_', word(filename, -1,sep='/')))
}




