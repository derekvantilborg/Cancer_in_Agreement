# This script contains all functions that are used throughout all other scripts.
# This script doesn't do anything by itself, but is called upon by others.
# All libraries are also imported here.

if (!requireNamespace("BiocManager", quietly = TRUE)){
  install.packages("BiocManager") 
  BiocManager::install("biomaRt")}

BiocManager::install("Homo.sapiens")
BiocManager::install("GOfuncR")

library(minet)
library(GeneNet)
library(stats)
library(psych)
library(ppcor)
library(igraph)
library(edgeR)
library(GOfuncR)
library(stringr)
library(readxl)
library(tibble)
library(biomaRt)
library(readr)
library(limma)
library(Rfast)
library(corrplot)
library(parallel)
library(plyr)
library(data.table)
library(pROC)
library(RColorBrewer)
library(ggsci)
library(comprehenr)
library(circlize)
library(impute)
library(colorspace) 
library(ggplotify)
library(dendextend)
library(ggplot2)
library(ggbeeswarm)
library(cowplot)
library(factoextra)
library(ggrepel)

library(devtools)
devtools::install_github("xia-lab/MetaboAnalystR", build = TRUE, build_vignettes = TRUE, build_manual =T)

# Color pallette that is used for all plots
cols = c(pal_npg("nrc", alpha = 1)(10), '#C67FD3', '#30605B')
cancer_colors = c(Renal = cols[1],
                  Liver = cols[2],
                  Breast = cols[3],
                  Colorectal = cols[4],
                  Lung = cols[5],
                  Gastric = cols[6],
                  Prostate = cols[7],
                  `Multiple myeloma` = cols[9])


## ---- Data Cleaning and Formatting ----

impute_and_log = function(networks, impute = T){
  # log transforms data and imputes missing data using knn imputation (impute package)
  # networks = list of two matrices (cancer,control). Output from: 'format_all_EMTAB()'
  
  network1 = networks$network1; network2 = networks$network2
  cpd_nms_1 = network1[[1]]; cpd_nms_2 = network2[[1]]
  
  network1 = log(network1[-1]) %>% mutate_if(is.numeric, function(x) ifelse(is.infinite(x), 0, x))
  network2 = log(network2[-1]) %>% mutate_if(is.numeric, function(x) ifelse(is.infinite(x), 0, x))
  
  if (impute){
    network1 = as.data.frame(impute.knn(as.matrix(network1), k=10)$data)
    network2 = as.data.frame(impute.knn(as.matrix(network2), k=10)$data)
  } 
  
  rownames(network1) = cpd_nms_1; network1 = t(network1)
  rownames(network2) = cpd_nms_2; network2 = t(network2)
  
  return(list(network1 = network1, network2 = network2))
}


format_all_EMTAB = function(Dataset){
  # split file into cancer and control group and put in a list
  Exp_data = Dataset
  Exp_data_networks = list(
    network1 = Exp_data[c(1, grep('tumor',  colnames(Exp_data)))],
    network2 = Exp_data[c(1, grep('normal',  colnames(Exp_data)))]
  )
  # impute missing data and log transform
  Exp_data_networks = impute_and_log(Exp_data_networks) 
  
  return(Exp_data_networks)
}

format_GSE47552 = function(dataset){
  # split file into cancer and control group and put in a list
  GSE47552 = dataset
  GSE47552_networks = list(
    network1 = GSE47552[c(1, grep('MM patient',  colnames(GSE47552)))],
    network2 = GSE47552[c(1, grep('Healthy',  colnames(GSE47552)))]
  )
  # impute missing data and log transform
  GSE47552_networks = impute_and_log(GSE47552_networks)  
  
  return(GSE47552_networks)
}

clean_GSE47552 = function(){
  # Read file
  GSE47552 <- read_excel("Data/Raw_data/Transcriptomics/GSE47552_series_matrix_MM.xlsx")
  # Subset data
  MM_and_normal = GSE47552[, c(1, grep(' MM ', as.vector(unlist(  GSE47552[38,2:ncol(GSE47552)]))),
                               grep('Healthy', as.vector(unlist(  GSE47552[38,2:ncol(GSE47552)]))))]
  names(MM_and_normal)[1:ncol(MM_and_normal)] = c('Probe', paste0(MM_and_normal[70,2:ncol(MM_and_normal)],'|',
                                                                  MM_and_normal[38,2:ncol(MM_and_normal)]))
  MM_and_normal = MM_and_normal[71:nrow(MM_and_normal),]
  
  # replace the affyID with gene symbol
  mart <- useMart(biomart = "ENSEMBL_MART_ENSEMBL",host = "www.ensembl.org", path = "/biomart/martservice", dataset = "hsapiens_gene_ensembl")
  
  hgnc <- getBM(attributes = c("affy_hugene_1_0_st_v1","hgnc_symbol"), 
                filters = "affy_hugene_1_0_st_v1", mart = mart, values = MM_and_normal$Probe)
  
  # Now match the array data probesets with the genes data frame
  m <- match(as.numeric(MM_and_normal$Probe), hgnc$affy_hugene_1_0_st_v1)
  # And append e.g. the HGNC symbol to the array data frame
  MM_and_normal = add_column(MM_and_normal, gene_name = hgnc[m, "hgnc_symbol"] , .after = 1)
  
  # remove NAs and empty gene names
  MM_and_normal$gene_name[MM_and_normal$gene_name == ''] = NA
  MM_and_normal = MM_and_normal[!is.na(MM_and_normal$gene_name),]
  
  # convert to numeric
  MM_and_normal = cbind(MM_and_normal[1:2], 
                        sapply(MM_and_normal[,3:ncol(MM_and_normal)], function(x) {as.numeric(as.character(x)) }))
  
  # calculate the mean expression value if there are multiple genes with the same name
  MM_and_normal = MM_and_normal %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  MM_and_normal$Probe = NULL
  
  # Format (split case and control,  impute and log transform) and save
  MM_and_normal = format_GSE47552(MM_and_normal)
  saveRDS(MM_and_normal, 'Data/Transcriptomics/GSE47552_Multiple myeloma.rds')
}

clean_6703 = function(){
  # Read file
  breast_6703 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6703_breast/esets_breast_exprs_genes.txt", 
                            "\t", escape_double = FALSE, trim_ws = TRUE)
  breast_6703_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6703_breast/E-MTAB-6703.sdrf.txt", 
                                 "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(breast_6703) = paste0('ID_', names(breast_6703), '|Type_', breast_6703_meta$`Characteristics[disease]`[match( names(breast_6703), breast_6703_meta$`Source Name`)])
  names(breast_6703)[1] = 'gene_name'
  # calculate the mean expression value if there are multiple genes with the same name
  breast_6703 = breast_6703 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  breast_6703 = format_all_EMTAB(breast_6703)
  saveRDS(breast_6703, 'Data/Transcriptomics/E-MTAB-6703_Breast.rds')
}

clean_6692 = function(){
  # Read file
  renal_6692 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6692_renal/esets_renal_exprs.txt", 
                           "\t", escape_double = FALSE, trim_ws = TRUE)
  renal_6692_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6692_renal/E-MTAB-6692.sdrf.txt", 
                                "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(renal_6692) = paste0('ID_', names(renal_6692), '|Type_', renal_6692_meta$`Characteristics[disease]`[match( names(renal_6692), renal_6692_meta$`Source Name`)])
  names(renal_6692)[1] = 'probe'
  
  # remove some samples (xenografts)
  renal_6692 = renal_6692[!grepl('graft', names(renal_6692))]
  
  # replace the affyID with gene symbol
  mart <- useMart(biomart = "ENSEMBL_MART_ENSEMBL",host = "www.ensembl.org", path = "/biomart/martservice", dataset = "hsapiens_gene_ensembl")
  hgnc <- getBM(attributes = c("affy_hg_u133_plus_2","hgnc_symbol"), 
                filters = "affy_hg_u133_plus_2", mart = mart, values = pancreas_6690$probe)
  # Now match the array data probesets with the genes data frame
  m <- match(renal_6692$probe, hgnc$affy_hg_u133_plus_2)
  # And append e.g. the HGNC symbol to the array data frame
  renal_6692 = add_column(renal_6692, gene_name = hgnc[m, "hgnc_symbol"] , .after = 1)
  
  # remove NAs and empty gene names
  renal_6692$gene_name[renal_6692$gene_name == ''] = NA
  renal_6692 = renal_6692[!is.na(renal_6692$gene_name),]
  renal_6692$probe = NULL
  # calculate the mean expression value if there are multiple genes with the same name
  renal_6692 = renal_6692 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  renal_6692 = format_all_EMTAB(renal_6692)
  saveRDS(renal_6692, 'Data/Transcriptomics/E-MTAB-6692_Renal.rds')
}

clean_6693 = function(){
  # Read file
  gastric_6693 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6693_gastric/esets_gastric_exprs.txt", 
                             "\t", escape_double = FALSE, trim_ws = TRUE)
  gastric_6693_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6693_gastric/E-MTAB-6693.sdrf.txt", 
                                  "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(gastric_6693) = paste0('ID_', names(gastric_6693), '|Type_', gastric_6693_meta$`Characteristics[disease]`[match( names(gastric_6693), gastric_6693_meta$`Source Name`)])
  names(gastric_6693)[1] = 'probe'
  
  # replace the affyID with gene symbol
  mart <- useMart(biomart = "ENSEMBL_MART_ENSEMBL",host = "www.ensembl.org", path = "/biomart/martservice", dataset = "hsapiens_gene_ensembl")
  hgnc <- getBM(attributes = c("affy_hg_u133_plus_2","hgnc_symbol"), 
                filters = "affy_hg_u133_plus_2", mart = mart, values = pancreas_6690$probe)
  # Now match the array data probesets with the genes data frame
  m <- match(gastric_6693$probe, hgnc$affy_hg_u133_plus_2)
  # And append e.g. the HGNC symbol to the array data frame
  gastric_6693 = add_column(gastric_6693, gene_name = hgnc[m, "hgnc_symbol"] , .after = 1)
  
  # remove NAs and empty gene names
  gastric_6693$gene_name[gastric_6693$gene_name == ''] = NA
  gastric_6693 = gastric_6693[!is.na(gastric_6693$gene_name),]
  gastric_6693$probe = NULL
  # calculate the mean expression value if there are multiple genes with the same name
  gastric_6693 = gastric_6693 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  gastric_6693 = format_all_EMTAB(gastric_6693)
  saveRDS(gastric_6693, 'Data/Transcriptomics/E-MTAB-6693_Gastric.rds')
}

clean_6694 = function(){
  # read file
  prostate_6694 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6694_prostate/esets_prostate_exprs.txt", 
                              "\t", escape_double = FALSE, trim_ws = TRUE)
  prostate_6694_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6694_prostate/E-MTAB-6694.sdrf.txt", 
                                   "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(prostate_6694) = paste0('ID_', names(prostate_6694), '|Type_', prostate_6694_meta$`Characteristics[disease]`[match( names(prostate_6694), prostate_6694_meta$`Source Name`)])
  names(prostate_6694)[1] = 'probe'
  
  # replace the affyID with gene symbol
  mart <- useMart(biomart = "ENSEMBL_MART_ENSEMBL",host = "www.ensembl.org", path = "/biomart/martservice", dataset = "hsapiens_gene_ensembl")
  
  hgnc <- getBM(attributes = c("affy_hg_u133_plus_2","hgnc_symbol"), 
                filters = "affy_hg_u133_plus_2", mart = mart, values = pancreas_6690$probe)
  # Now match the array data probesets with the genes data frame
  m <- match(prostate_6694$probe, hgnc$affy_hg_u133_plus_2)
  # And append e.g. the HGNC symbol to the array data frame
  prostate_6694 = add_column(prostate_6694, gene_name = hgnc[m, "hgnc_symbol"] , .after = 1)
  
  # remove NAs and empty gene names
  prostate_6694$gene_name[prostate_6694$gene_name == ''] = NA
  prostate_6694 = prostate_6694[!is.na(prostate_6694$gene_name),]
  prostate_6694$probe = NULL
  # calculate the mean expression value if there are multiple genes with the same name
  prostate_6694 = prostate_6694 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  prostate_6694 = format_all_EMTAB(prostate_6694)
  saveRDS(prostate_6694, 'Data/Transcriptomics/E-MTAB-6694_Prostate.rds')
}

clean_6695 = function(){
  # Read files
  liver_6695 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6695_liver/esets_liver_exprs.txt", 
                           "\t", escape_double = FALSE, trim_ws = TRUE)
  liver_6695_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6695_liver/E-MTAB-6695.sdrf.txt", 
                                "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(liver_6695) = paste0('ID_', names(liver_6695), '|Type_', liver_6695_meta$`Characteristics[disease]`[match( names(liver_6695), liver_6695_meta$`Source Name`)])
  names(liver_6695)[1] = 'probe'
  
  # replace the affyID with gene symbol
  mart <- useMart(biomart = "ENSEMBL_MART_ENSEMBL",host = "www.ensembl.org", path = "/biomart/martservice", dataset = "hsapiens_gene_ensembl")
  hgnc <- getBM(attributes = c("affy_hg_u133_plus_2","hgnc_symbol"), 
                filters = "affy_hg_u133_plus_2", mart = mart, values = pancreas_6690$probe)
  # Now match the array data probesets with the genes data frame
  m <- match(liver_6695$probe, hgnc$affy_hg_u133_plus_2)
  # And append e.g. the HGNC symbol to the array data frame
  liver_6695 = add_column(liver_6695, gene_name = hgnc[m, "hgnc_symbol"] , .after = 1)
  
  # remove NAs and empty gene names
  liver_6695$gene_name[liver_6695$gene_name == ''] = NA
  liver_6695 = liver_6695[!is.na(liver_6695$gene_name),]
  liver_6695$probe = NULL
  # calculate the mean expression value if there are multiple genes with the same name
  liver_6695 = liver_6695 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  liver_6695 = format_all_EMTAB(liver_6695)
  saveRDS(liver_6695, 'Data/Transcriptomics/E-MTAB-6695_Liver.rds')
}

clean_6698 = function(){
  # read file
  colorectal_6698 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6698_colorectal/esets_colorectal_exprs_genes.txt",
                                "\t", escape_double = FALSE, trim_ws = TRUE)
  colorectal_6698_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6698_colorectal/E-MTAB-6698.sdrf.txt",
                                     "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(colorectal_6698) = paste0('ID_', names(colorectal_6698), '|Type_', colorectal_6698_meta$`Characteristics[disease]`[match( names(colorectal_6698), colorectal_6698_meta$`Source Name`)])
  names(colorectal_6698)[1] = 'gene_name'
  
  # remove some samples (IBD, Adenoma)
  colorectal_6698 = colorectal_6698[!grepl('Adenoma|Inflammatory bowel diseases', names(colorectal_6698))]
  # calculate the mean expression value if there are multiple genes with the same name
  colorectal_6698 = colorectal_6698 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  colorectal_6698 = format_all_EMTAB(colorectal_6698)
  saveRDS(colorectal_6698, 'Data/Transcriptomics/E-MTAB-6698_Colorectal.rds')
}

clean_6699 = function(){
  # Read file
  lung_6699 <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6699_lung/esets_lung_exprs_genes.txt",
                          "\t", escape_double = FALSE, trim_ws = TRUE)
  lung_6699_meta <- read_delim("Data/Raw_data/Transcriptomics/E-MTAB-6699_lung/E-MTAB-6699.sdrf.txt",
                               "\t", escape_double = FALSE, trim_ws = TRUE)
  
  # Format sample names
  names(lung_6699) = paste0('ID_', names(lung_6699), '|Type_', lung_6699_meta$`Characteristics[disease]`[match( gsub('.CEL','',strsplit2(names(lung_6699),'_')[,1]), lung_6699_meta$`Source Name`)])
  names(lung_6699)[1] = 'gene_name'
  
  # calculate the mean expression value if there are multiple genes with the same name
  lung_6699 = lung_6699 %>%
    group_by(gene_name) %>%
    summarise_all("mean")
  
  # Format (split case and control,  impute and log transform) and save
  lung_6699 = format_all_EMTAB(lung_6699)
  saveRDS(lung_6699, 'Data/Transcriptomics/E-MTAB-6699_Lung.rds')
}

most_variable_genes = function(){
  # Subset all transcriptomics data sets by taking only the data of the most variable genes
  
  # function to find intersection between multiple vectors (extension of the regular intersect funtion)
  intersect_all <- function(a,b,...){
    Reduce(intersect, list(a,b,...))
  }
  
  Datasets = list.files('Data/Transcriptomics', full.names = T)
  # Move all data sets into a list
  dat = list()
  for (i in Datasets){dat[[length(dat)+1]] = readRDS(i)}
  names(dat) = gsub('.rds','',word(word(Datasets, -1, sep = fixed("/")), -1, sep = fixed("_")))
  
  # Find the genes common between all data sets
  common_genes = intersect_all(colnames(dat[[1]][[1]]), colnames(dat[[2]][[1]]), colnames(dat[[3]][[1]]), colnames(dat[[4]][[1]]),
                               colnames(dat[[5]][[1]]), colnames(dat[[6]][[1]]), colnames(dat[[7]][[1]]), colnames(dat[[8]][[1]]))
  
  # Make a giant matrix with all data
  All_dat = rbind.fill.matrix(dat[[1]][[1]], dat[[1]][[2]],
                              dat[[2]][[1]], dat[[2]][[2]],
                              dat[[3]][[1]], dat[[3]][[2]],
                              dat[[4]][[1]], dat[[4]][[2]],
                              dat[[5]][[1]], dat[[5]][[2]],
                              dat[[6]][[1]], dat[[6]][[2]],
                              dat[[7]][[1]], dat[[7]][[2]],
                              dat[[8]][[1]], dat[[8]][[2]])
  # Keep only the data from the common genes
  All_dat = All_dat[,colnames(All_dat) %in% common_genes]
  
  # Calculate all variances, select the genes with one standard deviation of variance above the mean variance. --> The sigma 1 most variable genes
  gene_vars = colVars(All_dat, parallel = T)
  All_dat = All_dat[,log(gene_vars) > (mean(log(gene_vars)) + sd(log(gene_vars)))]
  genes_to_select = colnames(All_dat)
  
  # Create new file of the original data with just the data from the most variable genes
  for (i in Datasets){
    dat = readRDS(i)
    dat[[1]] = dat[[1]][,colnames(dat[[1]]) %in% genes_to_select]
    dat[[2]] = dat[[2]][,colnames(dat[[2]]) %in% genes_to_select]
    
    saveRDS(dat, gsub('/Transcriptomics/','/Transcriptomics_most_variable_genes/',i))
  }
}

format_metabolite_names = function(s){
  # turns the first LETTER in a string to a capital letter, while keeping the rest lower case
  s = tolower(s)
  out = rep(NA, length(s))
  for (j in 1:length(s)){
    for (i in 1:length(unlist(strsplit(s[j], split = "")))){
      if (unlist(strsplit(s[j], split = ""))[i] %in% letters){
        break()}}
    out[j] = paste0(substring(s[j], 1,i-1), toupper(substring(s[j], i,i)), substring(s[j], i+1,nchar(s[j])))
  }
  return(out)
}

translate_metabolites <- function(metabolites, type){
  # convert metabolite name to a certain type. See 'translate_metabolites_multi'
  for(p in c('MetaboAnalystR')){
    if(!require(p,character.only = TRUE)) install.packages(p)
    library(p,character.only = TRUE)
  }
  mSet<-InitDataObjects("conc", "msetora", FALSE)
  mSet<-Setup.MapData(mSet, metabolites)
  sink('/dev/null')
  out = invisible(CrossReferencing(mSet, type))
  sink()
  return(out$name.map$hit.values)
}

translate_metabolites_multi <- function(name = NA, kegg = NA, hmdb = NA, pubchem = NA, chebi = NA, metlin = NA, replacement_name = NA){
  input = list(name=name, kegg=kegg, hmdb=hmdb, pubchem=pubchem, chebi=chebi, metlin=metlin, replacement_name)
  
  # translates metabolite names/id to a common name
  # name: metabolite names
  # kegg: kegg id
  # hmdb: hmdb id
  # pubchem: pubchem id
  # chebi: chebi id
  # metlin: metlin id
  # replacement: name that will be used if there is no match
  
  # check if input is given and if all inputs are of the same size
  if (all(is.na(input))){
    stop("No metabolites are given. Give at least one type of metabolite name(s)")}
  if (length(unique(lapply(input[!is.na(input)], length))) != 1){
    stop("Not all input vectors are of equal length")}
  for(p in c('MetaboAnalystR')){
    if(!require(p,character.only = TRUE)) install.packages(p)
    library(p,character.only = TRUE)
  }
  
  df = data.frame(matrix("", ncol = 0, nrow = length(input[!is.na(input)][[1]])))
  # translate metabolite names
  if (!all(is.na(name))){
    name[is.na(name)] <- '-'
    df$name = translate_metabolites(name,'name')}
  if (!all(is.na(kegg))){
    kegg[is.na(kegg)] <- '-'
    df$kegg = translate_metabolites(kegg,'kegg')}
  if (!all(is.na(hmdb))){
    hmdb[is.na(hmdb)] <- '-'
    df$hmdb = translate_metabolites(hmdb,'hmdb')}
  if (!all(is.na(pubchem))){
    pubchem[is.na(pubchem)] <- '-'
    df$pubchem = translate_metabolites(pubchem,'pubchem')}
  if (!all(is.na(chebi))){
    chebi[is.na(chebi)] <- '-'
    df$chebi = translate_metabolites(chebi,'chebi')}
  if (!all(is.na(metlin))){
    metlin[is.na(metlin)] <- '-'
    df$metlin = translate_metabolites(metlin,'metlin')}
  
  # Find most common name
  # create replacement names if applicable
  if (!all(is.na(replacement_name))){
    df$consensus = df$name
    repl = as.character(replacement_name[is.na(df$consensus)])
    df$consensus[is.na(df$consensus)] = repl}
  # else, create NAs
  else {df$consensus = rep(NA, nrow(df))}
  for(i in 1:nrow(df)){
    x = names(sort(table(unlist(df[i,])),decreasing=TRUE))
    if(length(x)>0){df$consensus[i] = x}}
  
  return(df)
}

## ---- Association Network Inferring -----

Diff.Conn.PCLRC.gmm <- function(X1, X2, corr.type = 'pearson', prob.threshold = 0.95, adjust.diff = 'BH', Niter = 1000, MaxPerm = 1000, frac=0.75, rank.thr=0.3, verbose = FALSE){
  
  # Calculate differential connectivity between the two networks calculated with PCLRC 
  # using partial correlation form data matrix X1 and X2
  #
  # Peform permutation test to assess statistical significance of the differential connectivity
  # Arguments:
  
  #   X1:   numeric matrix with the objects measurements.
  #   X1:   numeric matrix with the objects measurements.
  #   corr.type:      Type of correlation to be used
  #   prob.threshold: Probality treshold calculated by PCLRC on which to filter correlations. Default 0.95
  #   Niter:          Integer value with the number of iterations. Default is 1000
  #   frac:           Fraction of the samples to be considered at each iteration.
  #                   Default is 0.75 (75%)            
  #   rank.thr:       Fraction of the total predicted interactions to be kept at
  #                   each iteration. Default is 0.3 (30% highest scoring interations kept).
  #   Nperm:          Number of permutation for permutation test. Default 1000
  #   adjust.diff:    Pvalue correction for multiple testing. It uses p.adjust from stats package
  #                   Options are "holm", "hochberg", "hommel", "bonferroni", "BH", "BY",
  #                   "fdr", "none"). Benjamini-Hochberg is default metohd.
  #  
  #   Returns:  
  #
  #   Connectivity C1 of network 1 from X1
  #   Connectivity C2 of network 2 from X2
  #   Differential Connectivity C1 - C2
  #   Adjacency matrix AdjMat1 for data X1
  #   Adjacency matrix AdjMat2 for data Xw
  #   P-values for each connectivity
  #   Matrix of permutations
  
  #
  
  if(ncol(X1) != ncol(X2)) stop('X1 and X2 must have the same number of columns!')
  
  RES1 =   PCLRC.gmm(datamatrix = X1,  prob.threshold = prob.threshold, Niter=Niter, frac=frac, rank.thr=rank.thr)
  RES2 =   PCLRC.gmm(datamatrix = X2,  prob.threshold = prob.threshold, Niter=Niter, frac=frac, rank.thr=rank.thr)
  
  
  #CONNECTIVITY based on PCLRC
  W1C = RES1$CorrMatFiltered
  W2C = RES2$CorrMatFiltered
  
  G1C = abs(W1C) ##W1 is the correlation or mutual info for data set 1
  G2C = abs(W2C) ##W2 is the correlation or mutual info for data set 2
  
  Conn1_0C = rowSums(G1C)-1
  Conn2_0C = rowSums(G2C)-1
  
  
  #Calculate Differential connectivity
  diff0C = abs(Conn1_0C - Conn2_0C)
  
  
  
  ## PERMUTATION STARTS
  
  print('Entering permutation test')
  
  DIFFP_C = NULL
  DIFFP_M = NULL
  
  
  n1 = dim(X1)[1]
  n2 = dim(X2)[1]
  
  for (ii in 1:MaxPerm) {
    if(verbose)
      print(sprintf('Permutation %i of %i',ii,MaxPerm))
    X1p = NULL
    X2p = NULL
    for (jj in 1:dim(X1)[2])  {
      idx1p = sample(n1,n1)
      idx2p = sample(n2,n2)
      X1p = cbind(X1p,X1[idx1p,jj])
      X2p = cbind(X2p,X2[idx2p,jj])
    }
    
    # Calculate Corr
    
    RES1p =   PCLRC.gmm(X1p, prob.threshold = prob.threshold, Niter=Niter, frac=frac, rank.thr=rank.thr)
    RES2p =   PCLRC.gmm(X2p, prob.threshold = prob.threshold, Niter=Niter, frac=frac, rank.thr=rank.thr)
    
    
    W1pC = RES1p$CorrMatFiltered 
    W2pC = RES2p$CorrMatFiltered 
    
    
    #Calculate Connectivity based on CORR
    Conn_1C = rowSums(abs(W1pC))-1 
    Conn_2C = rowSums(abs(W2pC))-1 
    
    diffp_C = abs(Conn_1C- Conn_2C)
    DIFFP_C = cbind(DIFFP_C,diffp_C)
    
  }
  
  
  #Calculate Pvalue
  PVAL_C = NULL
  
  for(k in 1:dim(DIFFP_C)[1]) {
    
    LLC = length(which(DIFFP_C[k,]>diff0C[k]))
    PVAL_C[k] = (1+LLC )/MaxPerm
  }
  
  # Adjust p-value of differential connectivity
  PVAL_C_ADJ = p.adjust(PVAL_C,method = adjust.diff)
  
  
  names(Conn1_0C) = colnames(X1)
  names(Conn2_0C) = colnames(X1)
  names(diff0C) = colnames(X1)
  names(PVAL_C) = colnames(X1)
  names(PVAL_C) = colnames(X1)
  names(PVAL_C_ADJ) = colnames(X1)
  
  results = list(Conn_X1 = Conn1_0C, Conn_X2 = Conn2_0C, Diff_Conn = diff0C, Pval = PVAL_C, Pval_adj= PVAL_C_ADJ, AdjMat1 = W1C, AdjMat2 = W2C, Permutations = DIFFP_C, adjust.diff =  adjust.diff)
  
  
  return(results)
  
}

getHighestLinks <- function(matrix, rank.thr=0.3, verbose=FALSE)    {
  #Obtains the links with the hightes weigth from an weigthed adjacency matrix
  #
  # Args:
  #   weighedAdjacencyMatrix:  a weighted adjacency matrix (symmetric matrix)
  
  #   rank.thre: fraction of interactions to keep. Default0.3 
  #   Returns: binary matrix with only the higher links having non null values
  
  if(max(matrix, na.rm=TRUE)==0 ){
    th=0.01
    if(verbose) cat("null clr matrix \n")
  } else{                                      #get the threshold
    if(is.null(rank.thr)) {
      th <- min(matrix[matrix>0], na.rm=TRUE) 
    } else{
      th <- quantile((matrix[upper.tri(matrix)]), 1-rank.thr,na.rm=TRUE) 
      if(th==0){
        if(verbose) cat("threshold too low,  min of the (non-null) matrix chosen instead\n")
        th <- min(matrix[matrix>0])
      }
    }
  }
  ##select the ones that are above the threshold...
  net <- matrix
  net[which(net < th)] =0
  net[which(net >= th)] =1
  return(net)
}   

PCLRC.gmm <- function(datamatrix, prob.threshold = 0.95, Niter=1000, frac=0.75, rank.thr=0.3){
  
  #performs the PCLRC to infer probabilistic associations from a data matrix using 
  #a Gaussian Graphical model to estimate partial correlations
  #
  # Arguments:
  #   datamatrix:   numeric matrix with the objects measurements.
  #                 objects in rows, samples in cols.
  #   Niter:        Integer value with the number of iterations. Default is 1000
  #   frac:         Fraction of the samples to be considered at each iteration.
  #                 Default is 0.75 (75%)            
  #   rank.thr:     Fraction of the total predicted interactions to be kept at
  #                 each iteration. Default is 0.3 (30% highest scoring interations kept).     
  # Returns:  
  #
  #     Correlation matrix of datamatrix
  #     Filtered Correlation matrix of datamatrix
  #     Matrix of probabilities obtained using PCLRC
  #
  #     Requires GeneNet package
  #
  #     Saccenti et al 2015 J. Proteome Res., 2015, 14 (2)
  
  require(GeneNet)
  
  if(prob.threshold > 1 || prob.threshold < 0)
    stop('prob.threshold must be between 0 and 1')
  
  if(frac > 1 || frac < 0)
    stop('frac must be between 0 and 1. Default 0.75')
  
  if(rank.thr > 1 || rank.thr  < 0)
    stop('frac must be between 0 and 1. Default 0.35')
  
  nsamp=round(dim(datamatrix)[1]*frac) #number of samples per iteration
  Nvaliter=0  #number of valid iterations (no NAs generated)
  
  #this table will store the number of times an interaction was selected
  table <- mat.or.vec(dim(datamatrix)[2], dim(datamatrix)[2])
  
  
  for( it in (1:Niter)){
    #randomly select the samples
    samples=sample(dim(datamatrix)[1], nsamp)
    
    #build similarity matrix based on GMM from GeneNet
    
    similarityMatrixSubset <- ggm.estimate.pcor(as.matrix(datamatrix[samples,]), method = "static",verbose = F)
    
    similarityMatrixSubset = as.matrix(unclass(similarityMatrixSubset))
    similarityMatrixSubset <- similarityMatrixSubset^2
    
    #infeer network for this iteration using CLR
    
    adjSubset=clr(similarityMatrixSubset)
    
    if(!is.na(sum(adjSubset))){ #valid iteration
      #extract highest links
      out=getHighestLinks(adjSubset, rank.thr)
      #collect output
      table <- table+out
      Nvaliter=Nvaliter+1
    }
  }
  
  ProbMat  <- table/Nvaliter
  
  # Corr.mat = cor(datamatrix, method = "spearman")
  
  CorrMat = ggm.estimate.pcor(as.matrix(datamatrix), method = "static", verbose = F)
  CorrMat = as.matrix(unclass(CorrMat))
  
  CorrMat.Filtered  <- CorrMat
  CorrMat.Filtered[which(ProbMat<prob.threshold)] = 0
  diag(CorrMat.Filtered) = 1 #Force diagonal element equal to 1
  
  networks= list(CorrMatFiltered=CorrMat.Filtered,CorrMat=CorrMat,ProbMat=ProbMat,prob.threshold = prob.threshold)
  
  return(networks)
} 

## ---- Differential analysis ----

DGE <- function(data, gene_names, design_matrix,
                p_val_threshold = 0.05, adjust_method = 'BH'){
  
  # data: a dataframe of gene expression levels. Columns should be samples, rows should be genes
  # design matrix: two-column one-hot-encoded matrix for each sample called control, condition
  # control condition
  # 0       1
  # 1       0
  # 1       0
  # 0       1
  # 
  # gene_names: a vector of gene names corresponding to the rows of the expression data
  # p_val_threshold: Adjusted P value threshold to select significant genes
  # adjust_method: multiple testing method: bonferroni (family-wise error rate), BH (Benjamini & Hochberg)
  
  for(p in c('limma','edgeR','dplyr','ggplot2','ggrepel')){
    if(!require(p,character.only = TRUE)) install.packages(p)
    library(p,character.only = TRUE)
  }
  
  # Differential gene analysis
  fit <- lmFit(data, design_matrix)
  rownames(fit$coefficients) = gene_names
  cont.matrix <- makeContrasts(condition.vs.control = condition - control, levels=design_matrix)
  fit <- contrasts.fit(fit, cont.matrix)
  fit <- eBayes(fit)
  
  # results
  result <- topTable(fit, number = nrow(data), adjust = adjust_method)
  result = cbind(data.frame(gene_names = row.names(result)), result)
  row.names(result) = 1:nrow(result)
  
  # Summary of results (number of differentially expressed genes)
  up_down <- decideTests(fit, adjust.method = adjust_method, p.value = 0.05)
  cat('\nOverview of differential genes:\n\n')
  print(summary(up_down))
  
  # Generate a list of significantly differentially expressed genes
  if (summary(up_down)[1] + summary(up_down)[3] > 0){
    sig_results <- subset(result, adj.P.Val <= p_val_threshold)
    cat('\nMost significant genes:\n\n')
    print(head(sig_results, 10))
    sig_results = cbind(data.frame(gene_names = row.names(sig_results)), sig_results)
    row.names(sig_results) = 1:nrow(sig_results)
  } else {
    cat('\nNo significant results\n\n')
    sig_results = NA
  }
  return(list(fit = fit, result = result, up_down = up_down, sig_results = sig_results))
}

Diff_exp = function(dat){
  # Performs Differential Expression/Abundance Analysis using EdgeR
  # Uses pre-formatted data (list of two data frames: cancer and control data. First col is metab/gene names, rest are samples)
  # The design matrix is created based on the number of samples in the formatted data.
  
  # dat: path of .rds data formatted for GeneNet; A list of two matrices, the first for cancer and the second for the control group
  # Both matrices should contain the samples as rows and the genes/metabolites as columns
  # Returns a list with results
  
  nm = gsub('.rds','', strsplit(dat,'/')[[1]][5])
  dat = readRDS(dat)
  n1 = t(dat$network1)
  n2 = t(dat$network2)
  
  # Check if both networks contain the same genes/metabolites
  if(all(row.names(n1) != row.names(n2))) stop('Both networks must contain the same names')
  
  # infer design matrix from sample size of formatted data
  design_matrix <- cbind(control=c(rep(0,ncol(n1)),rep(1,ncol(n2))),
                         condition=c(rep(1,ncol(n1)),rep(0,ncol(n2))))
  
  # Perform DGE analysis
  Diff_metabolites = DGE(data = cbind(n1,n2), gene_names = row.names(n1), design_matrix = design_matrix)
  return(Diff_metabolites)
}

## ---- Pathway impact analysis ----

KEGG_pathway_analysis <- function(metabolites){
  # KEGG pathway analysis using MetaboAnalystR
  # https://www.metaboanalyst.ca/MetaboAnalyst/home.xhtml
  # returns pathways with their impact score (with p vals)
  # metabolites: vector of metabolite names
  
  for(p in c('MetaboAnalystR','ggrepel')){
    if(!require(p,character.only = TRUE)) install.packages(p)
    library(p,character.only = TRUE)
  }
  mSet <- InitDataObjects("conc", "pathora", FALSE)
  mSet <- Setup.MapData(mSet, metabolites)
  mSet <- CrossReferencing(mSet, "name")
  mSet <- CreateMappingResultTable(mSet)
  mSet <- SetKEGG.PathLib(mSet, "hsa", "current")
  mSet <- SetMetabolomeFilter(mSet, F);
  mSet <- CalculateOraScore(mSet, "rbc", "hyperg") #rcb = relative-betweeness centrality, hyperg = hypergeometric test
  mSet <- PlotPathSummary(mSet, "path_view_0_", "png", 72, width=NA)
  
  results = mSet$analSet$ora.mat
  colnames(results) <- c("Total", "Expected", "Hits", "p", 
                         "-log(p)", "Holm adjust", "FDR", "Impact")
  results = cbind(data.frame(pathway = row.names(results)), results)

  return(results)
}




joint_pathway_analysis <- function(genes, compounds, mode = 'joint'){
  # KEGG pathway joint analysis using MetaboAnalystR
  # https://www.metaboanalyst.ca/MetaboAnalyst/home.xhtml
  # returns pathways with their impact score (with p vals)
  # metabolites: vector of metabolite names
  # mode: can be 'joint' or 'genetic'. This determines if both the metabolites and genes are used or just genes
  
  for(p in c('MetaboAnalystR','ggrepel', 'ggrepel')){
    if(!require(p,character.only = TRUE)) install.packages(p)
    library(p,character.only = TRUE)
  }

  # Write the input to files, MetaboanalystR can only load them from files...
  write_tsv(genes, 'D_df.tsv'); write_tsv(compounds, 'M_df.tsv')
  
  mSet<-InitDataObjects("conc", "pathinteg", FALSE)
  mSet<-SetOrganism(mSet, "hsa")
  geneListFile<-"D_df.tsv"
  geneList<-readChar(geneListFile, file.info(geneListFile)$size)
  mSet<-PerformIntegGeneMapping(mSet, geneList, "hsa", "symbol")
  cmpdListFile<-"M_df.tsv"
  cmpdList<-readChar(cmpdListFile, file.info(cmpdListFile)$size)
  mSet<-PerformIntegCmpdMapping(mSet, cmpdList, "hsa", "name")
  mSet<-CreateMappingResultTable(mSet)
  mSet<-PrepareIntegData(mSet)
  if (mode == 'joint'){
    # metabolites and genes integrated. p-values are combined via weighted Z-tests
    mSet<-PerformIntegPathwayAnalysis(mSet, "bc", "hyper", "current", "all", "pvalp")
  } else if (mode == 'genetic'){
    # Genetic pathway impact only
    mSet<-PerformIntegPathwayAnalysis(mSet, "bc", "hyper", "current", "genetic", "query")
  } 

  results <- mSet$dataSet$path.mat
  colnames(results) <- c("Total", "Expected", "Hits", "p", 
                         "-log(p)", "Holm adjust", "FDR", "Impact")
  results = cbind(data.frame(pathway = row.names(results)), results)
  
  return(results)
}

## ---- Network Topology Measures ----

adj_to_network <- function(adj, remove_zeros = T){
  # transforms an adjecency network to a network in the form of: node1, node2, value.
  # removes diagonals
  adj <- lapply(rownames(adj),function(x)sapply(colnames(adj),function(y)list(x,y,adj[x,y])))
  adj <- t(matrix(unlist(adj),nrow=3))
  colnames(adj) <- c('node1', 'node2', 'value')
  adj_m <- as.data.frame(adj,stringsAsFactors=F)
  adj_m[,3] <- as.numeric(adj_m[,3])
  if (remove_zeros){
    adj_m = subset(adj_m, value != 0)
  }
  return(adj_m)
}

degree_from_net <- function(net, directed = F, normalize = T){
  # Returns a vector of nodes and their degree
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return( degree(gnet, normalized = normalize, mode="all"))
}

closeness_from_net <- function(net, directed = F, normalize = T){
  # Returns a vector of nodes and their degree
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return( closeness(gnet, mode="all", normalized = normalize) )
}

centralization_from_net <- function(net, directed=F, normalize = T){
  # Returns the normalized centralization
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  centr = centr_degree(gnet, mode="all", normalized = normalize)
  return(centr$centralization)
}

betweenness_from_net <- function(net, directed=F, normalize = T){
  # Returns the normalized centralization
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return(betweenness(gnet, directed = directed, normalized = normalize))
}

diameter_from_net <- function(net, directed=F){
  # Returns the diameter
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return(diameter(gnet, directed = directed))
}

mean_distance_from_net <- function(net, directed=F){
  # Returns the diameter
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return(mean_distance(gnet, directed = directed))
}

transitivity_from_net <- function(net, directed=F){
  # Returns the transitivity or correlation coefficient
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return(transitivity(gnet, type = 'global'))
}

hub_nodes_from_net <- function(net, directed = F){
  # Returns hub nodes as defined by Lu et al, 2007
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  return(1*(   transitivity(gnet, type = 'local') < 0.03 & degree(gnet, normalized = F, mode="all") > 5   ))
}


page_rank_from_net <- function(net, directed = F){
  # Returns the page rank for every vertex
  # uses the PRPACK library for the page rank algorithm, with a damping (d) of 0.85:
  #   ""Sergey Brin and Larry Page: The Anatomy of a Large-Scale Hypertextual Web Search Engine. 
  #     Proceedings of the 7th World-Wide Web Conference, Brisbane, Australia, April 1998.""
  # input is a network in the form of: node1, node2, value
  gnet = graph_from_data_frame(d=net, directed=directed) 
  pr = page_rank(gnet, algo = 'prpack', directed = F)$vector
  return(pr)
}





n_nodes_from_net = function(net){
  return(length(unique(net$node1)))
}

n_edges_from_net = function(net){
  return(nrow(net))
}

connectivity_from_adj_mat <- function(net){
  # Returns the connectivity for every node of a network
  # input is a network in the form of an adjacency matrix
  conn = rep(0, nrow(net)); names(conn) = colnames(net)
  for (i in 1:nrow(net)){
    conn[i] = sum(abs(net[,i]))-1
  }
  return(conn)
}


net_stats = function(net, discretize = T, threshold = 0.95){
  # returns a df summarizing some network stats giving two networks
  # RES: output from Diff.Conn.PCLRC.gmm
  # discretize: discretize a weighted matrix? (Bool)
  # threshold: discretizing value. Standard is 0.95; values below 0.95 will become 0, > 0.95 will become 1
  # connectivity is calculated on the non-discretized net anyhow
  
  conn = connectivity_from_adj_mat(net)
  
  if (discretize){net = ifelse(net < threshold, 0, 1)}
  
  net = adj_to_network(net)
  
  stats = c(n_nodes_from_net(net),
            n_edges_from_net(net),
            mean(conn),
            mean(degree_from_net(net)),
            mean(closeness_from_net(net)), 
            mean(betweenness_from_net(net)),
            diameter_from_net(net),
            mean_distance_from_net(net),
            mean(page_rank_from_net(net)),
            sum(hub_nodes_from_net(net)),
            centralization_from_net(net), 
            transitivity_from_net(net))
  
  names(stats) = c('n Nodes', 
                   'n Edges',
                   'Mean Connectivity', 
                   'Mean Degree', 
                   'Mean Closeness',
                   'Mean Betweenness',
                   'Diameter', 
                   'Mean Minimal Distance',
                   'Mean Page Rank',
                   'Hub Nodes',
                   'Centralization', 
                   'Transitivity')
  
  return(stats)
}


## ---- PCA ----

PCA_biplot2 = function(dat, title = 'PCA biplot', 
                       axes = c(1, 2),
                       individuals_color = '#000000', 
                       variable_arrow_alpha = 0.5,
                       variable_alpha = 0.5,
                       variable_label_alpha = 0.5,
                       variable_label_size = 3.5,
                       individuals_label_size = 4.5,
                       loading_scaling = 0.7,
                       cos2_label_treshold = NULL,
                       avoid_label = NULL,
                       alternative_ind_name = NULL){
  
  # Custom PCA based on the factoextra package
  # dat = dataframe
  # axex = Principal components to consider. Only works in two dimensions
  # avoid_label = vector of labels to not plot
  # alternative_ind_name = vector of alternative label names
  # ... = aesthetic options
  
  # calculate eigenvectors and find the %of variation + cos2
  pca <- prcomp(dat, scale = TRUE)
  scree = fviz_eig(pca)
  var <- facto_summarize(pca, element = "var", result = c("coord", "cos2"), axes = axes)
  ind <- facto_summarize(pca, element = "ind", result = c("coord", "cos2"), axes = axes)
  colnames(var)[2:3] <- c("x", "y")
  colnames(ind)[2:3] <- c("x", "y")
  
  # Scale Loadings 
  r <- min((max(ind[, "x"]) - min(ind[, "x"])/(max(var[, "x"]) - 
                                                 min(var[, "x"]))), (max(ind[, "y"]) - min(ind[, "y"])/(max(var[, 
                                                                                                                "y"]) - min(var[, "y"]))))
  var[, c("x", "y")] <- var[, c("x", "y")] * r * loading_scaling
  
  # Merge the indivduals (eigenvectors) and variables (loading rotations, now scaled)
  var$type = rep('var', nrow(var))
  ind$type = rep('idn', nrow(ind))
  bi = rbind(ind, var)
  bi$cos2[bi$type == 'idn'] = 0
  bi$name = as.character(bi$name)
  
  bi$name[bi$type == 'var'] = rownames(bi)[bi$type == 'var']
  
  if (!is.null(alternative_ind_name)){
    bi$name[bi$type == 'idn'] = alternative_ind_name
  }
  
  if (!is.null(cos2_label_treshold)){
    bi$name[bi$type == 'var' & bi$cos2 < cos2_label_treshold] = NA
  }
  
  if (!is.null(avoid_label)){
    bi$name[bi$name %in% avoid_label] = NA
  }
  
  hexcols = cancer_colors[match(strsplit2(bi$name, ' ')[,1], word(names(cancer_colors),1))]
  hexcols[is.na(hexcols)] = '#000000'
  
  p = ggplot(bi, aes(x = x, y =y)) +
    # first plot only the individuals by setting alpha to zero for the variables
    geom_point(aes(x, y), colour = hexcols, alpha = ifelse(bi$type == 'idn', 1, 0)) +
    geom_text_repel(aes(label = name), color = hexcols, size = ifelse(bi$type == 'idn', 4.5, 3.5), segment.size = 0.25, max.iter = 2500, force = 0.2, nudge_y = 0,
                    fontface="plain", alpha = ifelse(bi$type == 'idn', 1, 0.5)) +
    geom_segment(aes(x = 0, y = 0, xend = x, yend = y), #), color = cos2),
                 arrow = arrow(length = unit(0.2,"cm")),
                 alpha = ifelse(bi$type == 'var', variable_alpha, 0)) +
    geom_hline(yintercept = 0, linetype = 'dashed', alpha = 0.25) +
    geom_vline(xintercept = 0, linetype = 'dashed', alpha = 0.25) +
    labs(x = paste0('PC',axes[1], ' (',round(scree$data$eig[axes[1]],1),'%)'),
         y = paste0('PC',axes[2], ' (',round(scree$data$eig[axes[2]],1),'%)'),
         title = title,
         color = bquote('cos'^2) ) +
    theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
          panel.background = element_blank(),
          plot.title = element_text(hjust = 0.5),
          axis.text.x = element_text(size=14, face="bold", colour = "black"),
          axis.title.x = element_text(size=14, face="plain", colour = "black"),
          axis.text.y = element_text(size=14, face="bold", colour = "black"),
          axis.title.y = element_text(size=14, face="plain", colour = "black"),
          legend.title = element_text(size=14, face="bold", colour = "black"),
          legend.text = element_text(size=14, face="plain", colour = "black"),
          panel.grid.major = element_line(colour = "grey95"),
          panel.grid.minor = element_line(colour = "grey95"))
  
  print(p)
  return(p)
}


