# This script formats metabolimcs and transcriptomics data to a format that is readable by further analyses.
# It splits a dataframe into two seperate matrices with the metabolite name and metabolite abundance/ gene name and expression level per sample 
# for the cancer and the normal group.

# All Metabolomics data sets were mostly manually cleaned and formatted. 
# Since manual curation cannot be scripted, we provided the cleaned and formatted data sets.
# Three metabolomics datasets were obtained through the respective authors and cannot be directly downloaded from a repository.
# Transcriptomics data sets were all automatically cleaned and formatted. We therefore did not proive the data (also due to its size of ~1.1GB)
# All transcriptomics data sets can be downloaded from the links provided below.

# Used data sets:

# PubMed ID	    Database ID	Data Type	      Cancer            Type      doi/url
# __________________________________________________________________________________________________________________
#               ST000054	  Metabolomics	  Breast	          Tissue    10.21228/M8MS3J
# 27036109 [1]  ST000355	  Metabolomics	  Breast	          Plasma    10.21228/M86K6W
# 27036109 [1]  ST000356	  Metabolomics	  Breast	          Serum     10.21228/M86K6W
# 31794572 [2]              Metabolomics	  Breast	          Plasma    10.1371/journal.pone.0225129
# 25126899 [3]  ST000284	  Metabolomics	  Colorectal	      Serum     10.21228/M8FG61
# 29259332 [4]              Metabolomics	  Gastric	          Plasma    *
# 21518826 [5]              Metabolomics	  Liver	            Serum     10.1074/mcp.M110.004945
# 21518826 [5]              Metabolomics	  Liver	            Urine     10.1074/mcp.M110.004945
#               ST000390	  Metabolomics	  Lung	            Tissue    10.21228/M8PG66
#               ST000396	  Metabolomics	  Lung	            Plasma    10.21228/M86G6V
# 23543897 [6]              Metabolomics	  Lung	            Tissue    10.1007/s11306-012-0452-2
#               ST000221	  Metabolomics	  Multiple myeloma	Tissue    10.21228/M8R30R
# 23543897 [6]              Metabolomics	  Prostate	        Tissue    10.1007/s11306-012-0452-2
# 21348635 [7]              Metabolomics	  Renal	            Urine     *
# 31594947 [8] E-MTAB-6703	Transcriptomics	Breast	          Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6703/
# 31594947 [8] E-MTAB-6698	Transcriptomics	Colorectal	      Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6698/
# 31594947 [8] E-MTAB-6693	Transcriptomics	Gastric	          Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6693/
# 31594947 [8] E-MTAB-6695	Transcriptomics	Liver	            Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6695/
# 31594947 [8] E-MTAB-6699	Transcriptomics	Lung	            Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6699/
# 24816239 [9] GSE47552	    Transcriptomics	Multiple myeloma	Tissue    https://www.ncbi.nlm.nih.gov/sites/GDSbrowser?acc=GDS4968
# 31594947 [8] E-MTAB-6694	Transcriptomics	Prostate	        Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6694/
# 31594947 [8] E-MTAB-6692	Transcriptomics	Renal	            Tissue    https://www.ebi.ac.uk/arrayexpress/experiments/E-MTAB-6692/

# [1]	S. Huang, N. Chong, N. E. Lewis, W. Jia, G. Xie, and L. X. Garmire, “Novel personalized pathway-based metabolomics models reveal key metabolic pathways for breast cancer diagnosis,” Genome Med., vol. 8, no. 1, p. 34, Mar. 2016, doi: 10.1186/s13073-016-0289-9.
# [2]	J. Park, Y. Shin, T. H. Kim, D.-H. Kim, and A. Lee, “Plasma metabolites as possible biomarkers for diagnosis of breast cancer,” PloS One, vol. 14, no. 12, p. e0225129, 2019, doi: 10.1371/journal.pone.0225129.
# [3]	J. Zhu et al., “Colorectal cancer detection using targeted serum metabolic profiling,” J. Proteome Res., vol. 13, no. 9, pp. 4120–4130, Sep. 2014, doi: 10.1021/pr500494u.
# [4]	S. Lario et al., “Plasma sample based analysis of gastric cancer progression using targeted metabolomics,” Sci. Rep., vol. 7, no. 1, p. 17774, 19 2017, doi: 10.1038/s41598-017-17921-x.
# [5]	T. Chen et al., “Serum and urine metabolite profiling reveals potential biomarkers of human hepatocellular carcinoma,” Mol. Cell. Proteomics MCP, vol. 10, no. 7, p. M110.004945, Jul. 2011, doi: 10.1074/mcp.M110.004945.
# [6]	K. Kami et al., “Metabolomic profiling of lung and prostate tumor tissues by capillary electrophoresis time-of-flight mass spectrometry,” Metabolomics Off. J. Metabolomic Soc., vol. 9, no. 2, pp. 444–453, Apr. 2013, doi: 10.1007/s11306-012-0452-2.
# [7]	K. Kim, S. L. Taylor, S. Ganti, L. Guo, M. V. Osier, and R. H. Weiss, “Urine metabolomic analysis identifies potential biomarkers and pathogenic pathways in kidney cancer,” Omics J. Integr. Biol., vol. 15, no. 5, pp. 293–303, May 2011, doi: 10.1089/omi.2010.0094.
# [8]	S. B. Lim, S. J. Tan, W.-T. Lim, and C. T. Lim, “Compendiums of cancer transcriptomes for machine learning applications,” Sci. Data, vol. 6, no. 1, p. 194, Dec. 2019, doi: 10.1038/s41597-019-0207-2.
# [9]	L. López-Corral et al., “Transcriptome analysis reveals molecular profiles associated with evolving steps of monoclonal gammopathies,” Haematologica, vol. 99, no. 8, pp. 1365–1372, Aug. 2014, doi: 10.3324/haematol.2013.087809.

# * These data sets were obtained through contacting the corresponding authors.

## ---- Metabolites ----

# Metabolite names were first converted to the HMDB identifier using the 'translate_metabolites_multi()' function, 
# after which they were manually curated (this was needed for approx. a quarter of all metabolites).
# Data sets were split into two matrices by cancer and control samples.
# Next, abundance levels were log-transformed. 
# Metabolites that had missing data in more than 10% of the samples were discarted. 
# Finally, the remaining missing values were imputed using the knn imputation from the 'impute' R package: impute.knn(matrix, k=10)
# The resulting two matrices were bound in a list and stored as .rds file. They can be found in: Data/Metabolomics

## ---- Genes ----

# Transcriptomics data sets were automatically formatted.
# However, paths of all files must be modified in each of the functions below.
# The functions can be found in the file: R Code/R_functions.R

# script containing all functions
source('R Code/R_functions.R')

clean_GSE47552()
clean_6703()
clean_6692()
clean_6693()
clean_6694()
clean_6695()
clean_6698()
clean_6699()

# Subset the data based on the most variable genes (reduces data size for network inferring)
most_variable_genes()

