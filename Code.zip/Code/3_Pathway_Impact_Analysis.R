# This scripts performs the pathway impact analysis using various methods of selecting differces between cancer and control
# This script relies on functions from the MetaboAnalystR R library. We found that this library is very unstable
# The given functions should work, but we used the web app to achieve the same result. 
# https://www.metaboanalyst.ca/
# Chong, J., Wishart, D.S. and Xia, J. (2019) Using MetaboAnalyst 4.0 for Comprehensive and Integrative Metabolomics Data Analysis. Current Protocols in Bioinformatics 68, e86

# All results from this analysis are pre-run and can be found in 'Data/Pathway_Impact_Analysis'

# script containing all functions
source('R Code/R_functions.R')


## ---- Differentially abundant metabolites ----

DAM = list.files('Data/DE', pattern ='^Diff_Exp_Metab' , full.names = T)

for (filename in DAM){
  # Perform pathway analysis
  PA = KEGG_pathway_analysis( as.character(readRDS(filename)$sig_results[[2]]) )
  write.csv(PA, gsub('.rds','.csv', gsub('DE/','Pathway_Impact_Analysis/Diff_Exp_Metab/PA_', filename)), row.names = F)
}


gsub('.rds','.csv', paste0('PA_', word(filename, -1,-1, sep = '/')))

## ---- Differentially expressed genes ----

DEG = list.files('Data/DE', pattern ='^Diff_Exp_Genes' , full.names = T)

for (filename in DEG){
  # Perform pathway analysis
  PA = joint_pathway_analysis(as.character(readRDS(filename)$sig_results[[2]]), c(), mode = 'genetic')
  write.csv(PA, gsub('.rds','.csv', gsub('DE/','Pathway_Impact_Analysis/Diff_Exp_Genes/PA_', filename)), row.names = F)
}

## ---- Differentially connected metabolites ----

DCM = list.files('Data/DC', pattern ='^Diff_Conn_Metab' , full.names = T)

for (filename in DCM){
  # Perform pathway analysis
  PA = KEGG_pathway_analysis( names(readRDS(filename)$Pval_adj<0.05) )
  write.csv(PA, gsub('.rds','.csv', gsub('DC/','Pathway_Impact_Analysis/Diff_Conn_Metab/PA_', filename)), row.names = F)
}

## ---- Differentially connected genes ----

DCG = list.files('Data/DC', pattern ='^Diff_Conn_Genes' , full.names = T)

for (filename in DCG){
  # Perform pathway analysis
  PA = joint_pathway_analysis(names(readRDS(filename)$Pval_adj<0.05), c(), mode = 'genetic')
  write.csv(PA, gsub('.rds','.csv', gsub('DC/','Pathway_Impact_Analysis/Diff_Conn_Genes/PA_', filename)), row.names = F)
}


## ---- Differentially expressed Joint ----

cancer_types = c("Breast", 'Lung', 'Liver', 'Colorectal', 'Multiple myeloma', 'Renal', 'Prostate', 'Gastric')

# For every cancer type, find the diff. exp. genes and the diff exp. metab. from all data sets and peform joint pathway impact analysis on all
for (type in cancer_types){
  for (g in DEG[grepl(type, DEG)]){
    for (m in DAM[grepl(type, DAM)]){
      JPA = joint_pathway_analysis(names(readRDS(g)$Pval_adj<0.05), 
                                  names(readRDS(m)$Pval_adj<0.05), 
                                  mode = 'joint')
      write.csv(JPA, gsub('.rds','.csv', gsub('DC/','Pathway_Impact_Analysis/Joint_Diff_Exp/JPA_', m)), row.names = F)
    }
  }
}


## ---- Differentially connected Joint ----

cancer_types = c("Breast", 'Lung', 'Liver', 'Colorectal', 'Multiple myeloma', 'Renal', 'Prostate', 'Gastric')

# For every cancer type, find the diff. conn. genes and the diff conn. metab. from all data sets and peform joint pathway impact analysis on all
for (type in cancer_types){
  for (g in DCG[grepl(type, DCG)]){
    for (m in DCM[grepl(type, DCM)]){
      JPA = joint_pathway_analysis(as.character(readRDS(g)$sig_results[[2]]), 
                                   as.character(readRDS(m)$sig_results[[2]]), 
                                   mode = 'joint')
      write.csv(JPA, gsub('.rds','.csv', gsub('DC/','Pathway_Impact_Analysis/Joint_Diff_Conn/JPA_', m)), row.names = F)
    }
  }
}









