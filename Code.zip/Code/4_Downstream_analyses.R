# This script performs all downstream analyses and preps for generating all plots
# Data from the pathway impact analysis is formatted, after which a PCA is performed.
# Also, a table with network statistics for association networks is built.
# It uses the network statistics functions to calculate all kind of metrics. 
# A PCA is performed on the network statistics to see if cancer and normal networks are topologically different.
# Logistic regression is then performed on the networks to find the importance of each metric is determining cancer vs control.
# Finally, clustering analysis is performed on all pathway impact data and network data

# script containing all functions
source('R Code/R_functions.R')


All_Plot_Data = list()
### ---- Pathway Analysis DE Metab ----



Datasets_PA_DE_Metab = list.files('Data/Pathway_Impact_Analysis/Diff_Exp_Metab', '.csv', full.names = T)
PA_DE_Metab = data.frame(dataset = c(), cancer_type = c(), pathway = c(), folds = c(), impact = c(), FDR = c(), pval = c(), p.adj = c(), p.adj.FWER = c())
for (i in Datasets_PA_DE_Metab){
  dat  = read.csv(i)
  PA_DE_Metab = rbind(PA_DE_Metab, data.frame(dataset = rep( gsub('_', ' ', gsub('_diff_exp_pathway_anal.csv','',strsplit(i,'/')[[1]][4]))  , nrow(dat)), 
                                              cancer_type = rep( strsplit(strsplit(i,'/')[[1]][4],'_')[[1]][2]  , nrow(dat)), 
                                              pathway = dat$X, 
                                              folds = dat$Hits/dat$Expected,
                                              impact = dat$Impact, 
                                              FDR = dat$FDR, 
                                              pval = dat$Raw.p, 
                                              p.adj = p.adjust(dat$Raw.p, method = 'BH', n = length(dat$Raw.p)),
                                              p.adj.FWER = p.adjust(dat$Raw.p, method = 'bonferroni', n = length(dat$Raw.p)))
  )
}

PA_DE_Metab_sig = subset(PA_DE_Metab, p.adj < 0.05)

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DE_Metab_sig
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DE_Metab_sig'



## ---- PCA Pathway Analysis DE Metab ----



PA_DE_Metab_PCA = dcast(PA_DE_Metab_sig, dataset~pathway, value.var = "impact")
row.names(PA_DE_Metab_PCA) = paste0(strsplit2(PA_DE_Metab_PCA$dataset, ' ')[,2], ' ', strsplit2(PA_DE_Metab_PCA$dataset, ' ')[,3], ' (', strsplit2(PA_DE_Metab_PCA$dataset, ' ')[,1],')')
PA_DE_Metab_PCA = PA_DE_Metab_PCA[-1]
# remove NA and 0 variance cols
PA_DE_Metab_PCA[is.na(PA_DE_Metab_PCA)] = 0
PA_DE_Metab_PCA = PA_DE_Metab_PCA[,colSums(PA_DE_Metab_PCA) != 0]

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DE_Metab_PCA
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DE_Metab_PCA'



### ---- Pathway Analysis DC Metab ----



Datasets_PA_DC_Metab = list.files('Data/Pathway_Impact_Analysis/Diff_Conn_Metab', '.csv', full.names = T)
PA_DC_Metab = data.frame(dataset = c(), cancer_type = c(), pathway = c(), folds = c(), impact = c(), FDR = c(), pval = c(), p.adj = c(), p.adj.FWER = c())
for (i in Datasets_PA_DC_Metab){
  dat  = read.csv(i)
  PA_DC_Metab = rbind(PA_DC_Metab, data.frame(dataset = rep( gsub('_',' ', gsub('.csv','',strsplit(i,'/')[[1]][5]))  , nrow(dat)), 
                            cancer_type = rep( strsplit(strsplit(i,'/')[[1]][5],'_')[[1]][2]  , nrow(dat)), 
                            pathway = dat$X, 
                            folds = dat$Hits/dat$Expected,
                            impact = dat$Impact, 
                            FDR = dat$FDR, 
                            pval = dat$Raw.p, 
                            p.adj = p.adjust(dat$Raw.p, method = 'BH', n = length(dat$Raw.p)),
                            p.adj.FWER = p.adjust(dat$Raw.p, method = 'bonferroni', n = length(dat$Raw.p)))
  )
}

PA_DC_Metab_sig = subset(PA_DC_Metab, p.adj < 0.05)

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DC_Metab_sig
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DC_Metab_sig'



## ---- PCA Pathway Analysis DC Metab ----



PA_DC_Metab_PCA = dcast(PA_DC_Metab_sig, dataset~pathway, value.var = "impact")
row.names(PA_DC_Metab_PCA) = paste0(strsplit2(PA_DC_Metab_PCA$dataset, ' ')[,2], ' ', strsplit2(PA_DC_Metab_PCA$dataset, ' ')[,3], ' (', strsplit2(PA_DC_Metab_PCA$dataset, ' ')[,1],')')
PA_DC_Metab_PCA = PA_DC_Metab_PCA[-1]
# remove NA and 0 variance cols
PA_DC_Metab_PCA[is.na(PA_DC_Metab_PCA)] = 0
PA_DC_Metab_PCA = PA_DC_Metab_PCA[,colSums(PA_DC_Metab_PCA) != 0]

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DC_Metab_PCA
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DC_Metab_PCA'



### ---- Pathway Analysis DE Genes ----



Datasets_PA_DE_Genes = list.files('Data/Pathway_Impact_Analysis/Diff_Exp_Genes', '.csv', full.names = T)
PA_DE_Genes = data.frame(dataset = c(), cancer_type = c(), pathway = c(), folds = c(), impact = c(), FDR = c(), pval = c(), p.adj = c(),p.adj.FWER = c())
for (i in Datasets_PA_DE_Genes){
  dat  = read.csv(i)
  PA_DE_Genes = rbind(PA_DE_Genes, data.frame(dataset = rep( gsub('Pathway_anal_|_DE_genes.csv','',strsplit(i,'/')[[1]][4])  , nrow(dat)), 
                                              cancer_type = rep( gsub('Pathway_anal_|_DE_genes.csv','',strsplit(i,'/')[[1]][4])  , nrow(dat)), 
                                              pathway = dat$X, 
                                              folds = dat$Hits/dat$Expected,
                                              impact = dat$Impact, 
                                              FDR = dat$FDR, 
                                              pval = dat$Raw.p, 
                                              p.adj = p.adjust(dat$Raw.p, method = 'BH', n = length(dat$Raw.p)),
                                              p.adj.FWER = p.adjust(dat$Raw.p, method = 'bonferroni', n = length(dat$Raw.p)))
  )
}

PA_DE_Genes_sig = subset(PA_DE_Genes, p.adj.FWER < 0.05)

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DE_Genes_sig
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DE_Genes_sig'



## ---- PCA Pathway Analysis DE Genes ----



PA_DE_Genes_PCA = dcast(PA_DE_Genes_sig, dataset~pathway, value.var = "impact")
row.names(PA_DE_Genes_PCA) = PA_DE_Genes_PCA$dataset
PA_DE_Genes_PCA = PA_DE_Genes_PCA[-1]
# remove NA and 0 variance cols
PA_DE_Genes_PCA[is.na(PA_DE_Genes_PCA)] = 0
PA_DE_Genes_PCA = PA_DE_Genes_PCA[,colSums(PA_DE_Genes_PCA) != 0]

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DE_Genes_PCA
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DE_Genes_PCA'



### ---- Pathway Analysis DC Genes ----



# Datasets_PA_DC_Genes = list.files('Results/Manual Pathway Analysis/Transcriptomics/DC', '.csv', full.names = T)
Datasets_PA_DC_Genes = list.files('Data/Pathway_Impact_Analysis/Diff_Conn_Genes', '.csv', full.names = T)

PA_DC_Genes = data.frame(dataset = c(), cancer_type = c(), pathway = c(), folds = c(), impact = c(), FDR = c(), pval = c(), p.adj = c(),p.adj.FWER = c())
for (i in Datasets_PA_DC_Genes){
  dat  = read.csv(i)
  PA_DC_Genes = rbind(PA_DC_Genes, data.frame(dataset = rep(gsub('.csv', '', strsplit(i,'/')[[1]][5])  , nrow(dat)), 
                                              cancer_type = rep(gsub('.csv', '',strsplit(i,'/')[[1]][5])  , nrow(dat)), 
                                              pathway = dat$X, 
                                              folds = dat$Hits/dat$Expected,
                                              impact = dat$Impact, 
                                              FDR = dat$FDR, 
                                              pval = dat$Raw.p, 
                                              p.adj = p.adjust(dat$Raw.p, method = 'BH', n = length(dat$Raw.p)),
                                              p.adj.FWER = p.adjust(dat$Raw.p, method = 'bonferroni', n = length(dat$Raw.p)))
  )
}

PA_DC_Genes_sig = subset(PA_DC_Genes, p.adj < 0.05)

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DC_Genes_sig
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DC_Genes_sig'



## ---- PCA Pathway Analysis DE Genes ----



PA_DC_Genes_PCA = dcast(PA_DC_Genes_sig, dataset~pathway, value.var = "impact")
row.names(PA_DC_Genes_PCA) = PA_DC_Genes_PCA$dataset
PA_DC_Genes_PCA = PA_DC_Genes_PCA[-1]
# remove NA and 0 variance cols
PA_DC_Genes_PCA[is.na(PA_DC_Genes_PCA)] = 0
PA_DC_Genes_PCA = PA_DC_Genes_PCA[,colSums(PA_DC_Genes_PCA) != 0]

All_Plot_Data[[length(All_Plot_Data)+1]] = PA_DC_Genes_PCA
names(All_Plot_Data)[length(All_Plot_Data)] = 'PA_DC_Genes_PCA'



## ---- Network Stats Metab ----



Datasets_DC_Metab = list.files('Data/DC', '^Diff_Conn_Metab_', full.names = T)

all_stats = list()
for (i in Datasets_DC_Metab){
  # Read data and calculate network stats for both networks (cancer and control)
  nets = readRDS(i)
  stats_cancer = net_stats(nets$AdjMat1, discretize = F)
  stats_control = net_stats(nets$AdjMat2, discretize = F)
  # Add to list
  all_stats[[length(all_stats)+1]] = stats_cancer
  names(all_stats)[length(all_stats)] = paste('cancer', gsub('_',' ',gsub('Diff_Conn_|.rds','',strsplit(i,'/')[[1]][3])))
  all_stats[[length(all_stats)+1]] = stats_control
  names(all_stats)[length(all_stats)] = paste('control', gsub('_',' ',gsub('Diff_Conn_|.rds','',strsplit(i,'/')[[1]][3])))
}
st = as.data.frame(all_stats)
names(st) = gsub('\\.',' ', names(st))
# transpose
st = as.data.frame(t(st))

write.csv(st, 'Data/stats_metabolomics.csv', row.names = T)
All_Plot_Data[[length(All_Plot_Data)+1]] = st
names(All_Plot_Data)[length(All_Plot_Data)] = 'Network_Stats_Metab'



# ---- Network Stats Genes ----



# Datasets_DC_Genes = list.files('Data/DC/genes', '*.rds', full.names = T)
Datasets_DC_Genes = list.files('Data/DC/', '^Diff_Conn_Genes_', full.names = T)
all_stats_exp = list()
for (i in Datasets_DC_Genes){
  # Read data and calculate network stats for both networks (cancer and control)
  nets = readRDS(i)
  stats_cancer = net_stats(nets$AdjMat1, discretize = F)
  stats_control = net_stats(nets$AdjMat2, discretize = F)
  # Add to list
  all_stats_exp[[length(all_stats_exp)+1]] = stats_cancer
  names(all_stats_exp)[length(all_stats_exp)] = paste('cancer', gsub('.rds','',strsplit(strsplit(i,'/')[[1]][4],'_')[[1]][4]))
  all_stats_exp[[length(all_stats_exp)+1]] = stats_control
  names(all_stats_exp)[length(all_stats_exp)] = paste('control', gsub('.rds','',strsplit(strsplit(i,'/')[[1]][4],'_')[[1]][4]))
}
st_exp = as.data.frame(all_stats_exp)
names(st_exp) = gsub('\\.',' ', names(st_exp))
# transpose
st_exp = as.data.frame(t(st_exp))

write.csv(st_exp, 'Data/stats_transcriptomics.csv', row.names = T)
All_Plot_Data[[length(All_Plot_Data)+1]] = st_exp
names(All_Plot_Data)[length(All_Plot_Data)] = 'Network_Stats_Genes'



## ---- Log Regression Metab ----



st$Cancer = ifelse(grepl('cancer', rownames(st)), 1, 0)
st[1:12] = scale(st[1:12])
st$Cancer = factor(st$Cancer)
# shuffle data
st <- st[sample(nrow(st)), ]
names(st) = gsub(' ', '_', names(st))
results = data.frame(pred = c(), true = c(), k = c(), measure = c())
# Perofrm log regression for every measure with leave one out cross validation
for (msr in 1:12){
  for (i in 1:nrow(st)){
    data_train = st[-i,]
    model = glm(as.formula(paste('Cancer ~', names(st)[msr])), data = data_train, family = 'binomial')
    results = rbind(results, data.frame(pred = predict(model, data_train), true = data_train$Cancer, k = rep(i, nrow(data_train)), measure =  gsub('_',' ', names(st)[msr])))
  }
}
# Calculate specificity and sensitivity for all measures
roc_dat = data.frame(measure = c(), specificities = c(), sensitivities = c(), auc = c())
for (i in unique(results$measure)){
  r = roc(true~pred,data = subset(results, measure == i) )
  roc_dat = rbind(roc_dat, data.frame(measure = rep(i, length(r$sensitivities)), 
                                      specificities = r$specificities, 
                                      sensitivities = r$sensitivities, 
                                      auc = rep(r$auc, length(r$sensitivities))))
}
# ROC plot
aucs = roc_dat %>% group_by(measure) %>% summarise_all("mean")
roc_dat$measure = factor(paste0(as.character(roc_dat$measure), ', AUC = ', round(aucs$auc[match(as.character(roc_dat$measure), as.character(aucs$measure))],3)))
st$Cancer = NULL

All_Plot_Data[[length(All_Plot_Data)+1]] = roc_dat
names(All_Plot_Data)[length(All_Plot_Data)] = 'ROC_Metab'



## ---- Log Regression Genes ----



st_exp_bu = st_exp
st_exp$Cancer = ifelse(grepl('cancer', rownames(st_exp)), 1, 0)

st_exp = st_exp[-1] # Remove n nodes, as all networks are between the same genes
st_exp[1:11] = scale(st_exp[1:11])
st_exp$Cancer = factor(st_exp$Cancer)
# Remove this in final version <--------------------------------------------------------------------------------------------- !!!!!!!
# st_exp[,1] = rep(0, nrow(st_exp))
# shuffle data
st_exp <- st_exp[sample(nrow(st_exp)), ]
names(st_exp) = gsub(' ', '_', names(st_exp))
results_exp = data.frame(pred = c(), true = c(), k = c(), measure = c())
# Perofrm log regression for every measure with leave one out cross validation
for (msr in 1:11){
  for (i in 1:nrow(st_exp)){
    data_train = st_exp[-i,]
    model = glm(as.formula(paste('Cancer ~', names(st_exp)[msr])), data = data_train, family = 'binomial')
    results_exp = rbind(results_exp, data.frame(pred = predict(model, data_train), true = data_train$Cancer, k = rep(i, nrow(data_train)), measure =  gsub('_',' ', names(st_exp)[msr])))
  }
}
# Calculate specificity and sensitivity for all measures
roc_dat_exp = data.frame(measure = c(), specificities = c(), sensitivities = c(), auc = c())
for (i in unique(results_exp$measure)){
  r = roc(true~pred,data = subset(results_exp, measure == i) )
  roc_dat_exp = rbind(roc_dat_exp, data.frame(measure = rep(i, length(r$sensitivities)), 
                                              specificities = r$specificities, 
                                              sensitivities = r$sensitivities, 
                                              auc = rep(r$auc, length(r$sensitivities))))
}
# ROC plot
aucs_exp = roc_dat_exp %>% group_by(measure) %>% summarise_all("mean")
roc_dat_exp$measure = factor(paste0(as.character(roc_dat_exp$measure), ', AUC = ', round(aucs_exp$auc[match(as.character(roc_dat_exp$measure), as.character(aucs_exp$measure))],3)))
# st_exp$Cancer = NULL

All_Plot_Data[[length(All_Plot_Data)+1]] = roc_dat_exp
names(All_Plot_Data)[length(All_Plot_Data)] = 'ROC_Genes'



### ---- Joint Pathway Analysis DE ----



Datasets_JPA_DE = list.files('Data/Pathway_Impact_Analysis/Joint_Diff_Metab', '.csv', full.names = T)
JPA_DE = data.frame(dataset = c(), cancer_type = c(), pathway = c(), folds = c(), impact = c(), FDR = c(), pval = c(), p.adj = c(), p.adj.FWER = c())
for (i in Datasets_JPA_DE){
  dat  = read.csv(i)
  JPA_DE = rbind(JPA_DE, data.frame(dataset = rep( gsub('_', ' ', gsub('jointpa_|.csv','',strsplit(i,'/')[[1]][4]))  , nrow(dat)), 
                                              cancer_type = rep( strsplit(strsplit(i,'/')[[1]][4],'_')[[1]][3]  , nrow(dat)), 
                                              pathway = dat$X, 
                                              folds = dat$Hits/dat$Expected,
                                              impact = dat$Impact, 
                                              FDR = dat$FDR, 
                                              pval = dat$Raw.p, 
                                              p.adj = p.adjust(dat$Raw.p, method = 'BH', n = length(dat$Raw.p)),
                                              p.adj.FWER = p.adjust(dat$Raw.p, method = 'bonferroni', n = length(dat$Raw.p)))
  )
}

JPA_DE_sig = subset(JPA_DE, p.adj < 0.05)
# JPA_DE_sig = subset(JPA_DE_sig, impact >= 0.2)

JPA_DE_sig[JPA_DE_sig$impact > 1,]$impact = 1

All_Plot_Data[[length(All_Plot_Data)+1]] = JPA_DE_sig
names(All_Plot_Data)[length(All_Plot_Data)] = 'JPA_DE_sig'


## ---- PCA Joint Pathway Analysis DE ----



JPA_DE_PCA = dcast(subset(JPA_DE, p.adj < 0.05), dataset~pathway, value.var = "impact")
row.names(JPA_DE_PCA) = paste0(strsplit2(JPA_DE_PCA$dataset, ' ')[,2], ' ', strsplit2(JPA_DE_PCA$dataset, ' ')[,3], ' (', strsplit2(JPA_DE_PCA$dataset, ' ')[,1],')')
JPA_DE_PCA = JPA_DE_PCA[-1]
# remove NA and 0 variance cols
JPA_DE_PCA[is.na(JPA_DE_PCA)] = 0
JPA_DE_PCA = JPA_DE_PCA[,colSums(JPA_DE_PCA) != 0]

All_Plot_Data[[length(All_Plot_Data)+1]] = JPA_DE_PCA
names(All_Plot_Data)[length(All_Plot_Data)] = 'JPA_DE_PCA'



### ---- Joint Pathway Analysis DC ----



# Datasets_JPA_DC = list.files('Results/Joint Pathway Analysis/All pathways joint/DC', '.csv', full.names = T)
Datasets_JPA_DC = list.files('Data/Pathway_Impact_Analysis/Joint_Diff_Conn', '.csv', full.names = T)
JPA_DC = data.frame(dataset = c(), cancer_type = c(), pathway = c(), folds = c(), impact = c(), FDR = c(), pval = c(), p.adj = c(), p.adj.FWER = c())
for (i in Datasets_JPA_DC){
  dat  = read.csv(i)
  JPA_DC = rbind(JPA_DC, data.frame(dataset = rep( gsub('_', ' ', gsub('jointpa_|.csv','',strsplit(i,'/')[[1]][5]))  , nrow(dat)), 
                                    cancer_type = rep( strsplit(strsplit(i,'/')[[1]][5],'_')[[1]][3]  , nrow(dat)), 
                                    pathway = dat$X, 
                                    folds = dat$Hits/dat$Expected,
                                    impact = dat$Impact, 
                                    FDR = dat$FDR, 
                                    pval = dat$Raw.p, 
                                    p.adj = p.adjust(dat$Raw.p, method = 'BH', n = length(dat$Raw.p)),
                                    p.adj.FWER = p.adjust(dat$Raw.p, method = 'bonferroni', n = length(dat$Raw.p)))
  )
}

JPA_DC_sig = subset(JPA_DC, p.adj < 0.05)
# JPA_DC_sig = subset(JPA_DC_sig, impact >= 0.2)

All_Plot_Data[[length(All_Plot_Data)+1]] = JPA_DC_sig
names(All_Plot_Data)[length(All_Plot_Data)] = 'JPA_DC_sig'


## ---- PCA Joint Pathway Analysis DC ----

JPA_DC_PCA = dcast(subset(JPA_DC, p.adj < 0.05), dataset~pathway, value.var = "impact")
row.names(JPA_DC_PCA) = paste0(strsplit2(JPA_DC_PCA$dataset, ' ')[,2], ' ', strsplit2(JPA_DC_PCA$dataset, ' ')[,3], ' (', strsplit2(JPA_DC_PCA$dataset, ' ')[,1],')')
JPA_DC_PCA = JPA_DC_PCA[-1]
# remove NA and 0 variance cols
JPA_DC_PCA[is.na(JPA_DC_PCA)] = 0
JPA_DC_PCA = JPA_DC_PCA[,colSums(JPA_DC_PCA) != 0]

All_Plot_Data[[length(All_Plot_Data)+1]] = JPA_DC_PCA
names(All_Plot_Data)[length(All_Plot_Data)] = 'JPA_DC_PCA'



## ---- Metabolite co-occurence tables ----



# Open all formatted Metabolomics data sets and put them in a list
metabolite_datasets = list.files('Data/Metabolomics', '*.rds', full.names = T)

all_metabolite_datasets = list()
for (i in metabolite_datasets){
  all_metabolite_datasets[[length(all_metabolite_datasets)+1]] = readRDS(i)
}
names(all_metabolite_datasets) = gsub('.rds', '', gsub('Data/Metabolomics/','',metabolite_datasets))

# Count metabolites and samples per dataset
size = data.frame(dataset = names(all_metabolite_datasets), 
                  n_metabolites = rep(NA,length(all_metabolite_datasets)),
                  n_cancer_samples = rep(NA,length(all_metabolite_datasets)),
                  n_control_samples = rep(NA,length(all_metabolite_datasets)))
for (i in 1:length(all_metabolite_datasets)){
  size[i,2:4] = c(ncol(all_metabolite_datasets[[i]]$network1),
                  nrow(all_metabolite_datasets[[i]]$network1),
                  nrow(all_metabolite_datasets[[i]]$network2))
  }
# Metabolite names per dataset
all_metabolites = list()
for (i in all_metabolite_datasets){
  all_metabolites[[length(all_metabolites)+1]] = colnames(i$network1)
}
names(all_metabolites) = names(all_metabolite_datasets)
all_metabolites_combined = data.frame(Metabolite_name = as.character(unique(to_vec(for(i in all_metabolites) i)))    )
all_metabolites_combined = cbind(all_metabolites_combined, as.data.frame(to_list(  for(i in all_metabolites) i[match(all_metabolites_combined$Metabolite_name, i)])) )
names(all_metabolites_combined)[-1] = names(all_metabolites)
# count co-occurence per metabolite
nr_of_metabolites = ncol(all_metabolites_combined) - rowSums(is.na(all_metabolites_combined)) -1
# Create table with X if metabolite occurs in dataset
all_metabolites_combined <- data.frame(lapply(all_metabolites_combined, as.character), stringsAsFactors=FALSE)
all_metabolites_combined[2:ncol(all_metabolites_combined)][!is.na(all_metabolites_combined[2:ncol(all_metabolites_combined)])] = 'X'
all_metabolites_combined[2:ncol(all_metabolites_combined)][is.na(all_metabolites_combined[2:ncol(all_metabolites_combined)])] = ''
# Format column names and order based on co-occurence
splt = strsplit2(names(all_metabolites_combined)[-1], '_')
names(all_metabolites_combined) = c('Metabolite', paste0(gsub('.Adenocarcinoma', '', gsub('.Myeloma' ,' myeloma' ,splt[,2])),' (', splt[,3], ', ', splt[,1], ')'))
all_metabolites_combined = all_metabolites_combined[order(nr_of_metabolites, decreasing = T),]
all_metabolites_combined$`Co-occurence` = nr_of_metabolites[order(nr_of_metabolites, decreasing = T)]
all_metabolites_combined = all_metabolites_combined[c(1,ncol(all_metabolites_combined), 2:(ncol(all_metabolites_combined)-1))]

write.csv(all_metabolites_combined, 'all_metabolites_across_data_sets.csv', row.names = F)





## ---- Differential genes/metabolites across data sets tables ----
DE_datasets = list.files('Data/DE', '*.rds', full.names = T)
DE_metabs_datasets = DE_datasets[c(9:22)]
DE_genes_datasets = DE_datasets[c(1:8)]

# Differentially Abundant Metabolites
DE_metab = data.frame('Dataset' = NA, 'Cancer' = NA, 'Type' = NA, 'Metabolites' = NA, 'Differentially abundant metabolites' = NA)[F,]
for (i in 1:length(DE_metabs_datasets)){
  dat = readRDS(DE_metabs_datasets[i])
  DE_metab[nrow(DE_metab)+1,] = c(strsplit(strsplit(DE_metabs_datasets[i],'/')[[1]][3],'_')[[1]][1],
                                  strsplit(strsplit(DE_metabs_datasets[i],'/')[[1]][3],'_')[[1]][2],
                                  strsplit(strsplit(DE_metabs_datasets[i],'/')[[1]][3],'_')[[1]][3],
                                  nrow(dat$result),
                                  nrow(subset(dat$result,adj.P.Val < 0.05)))
}
write.csv(DE_metab, 'DE_metabolites_stats.csv', row.names = F)

# Differentially Expressed Genes
DE_genes = data.frame('Dataset' = NA, 'Cancer' = NA, 'Genes' = NA, 'Differentially expressed genes' = NA)[F,]
for (i in 1:length(DE_genes_datasets)){
  dat = readRDS(DE_genes_datasets[i])
  dat$result$adj.P.Val.FWER = p.adjust(dat$result$P.Value, 'bonferroni')
  DE_genes[nrow(DE_genes)+1,] = c(strsplit(strsplit(DE_genes_datasets[i],'/')[[1]][3],'_')[[1]][1],
                                  strsplit(strsplit(DE_genes_datasets[i],'/')[[1]][3],'_')[[1]][2],
                                  nrow(dat$result),
                                  nrow(subset(dat$result,adj.P.Val.FWER < 0.05)))
}
write.csv(DE_genes, 'DE_genes_stats.csv', row.names = F)

# Differentially Connected Metabolites 
DC_Metab_Datasets = list.files('Data/DC', '*.rds', full.names = T)
DC_Metab = data.frame('Dataset' = NA, 'Cancer' = NA, 'Type' = NA, 'Metabolites' = NA, 'Differentially Connected Metabolites' = NA)[F,]
for (i in 1:length(DC_Metab_Datasets)){
  dat = readRDS(DC_Metab_Datasets[i])
  sig_diff_conn_metab = names(dat$Pval_adj)[dat$Pval_adj < 0.05]
  DC_Metab[nrow(DC_Metab)+1,] = c(strsplit(strsplit(DC_Metab_Datasets[i],'/')[[1]][3],'_')[[1]][3],
                                  gsub(' Adenocarcinoma', '', gsub('Myeloma','myeloma',strsplit(strsplit(DC_Metab_Datasets[i],'/')[[1]][3],'_')[[1]][4])),
                                  gsub('.rds','', strsplit(strsplit(DC_Metab_Datasets[i],'/')[[1]][3],'_')[[1]][5]),
                                  length(dat$Pval_adj),
                                  length(which(dat$Pval_adj < 0.01)))
}
write.csv(DC_Metab, 'DC_Metab_stats.csv', row.names = F)



## ---- GO analysis -----

# Differentially Expressed Genes 

Diff_exp_datasets = list.files('Data/DE', '^Diff_Exp_Genes', full.names = T)[1:8]
GO = list()

for (i in Diff_exp_datasets){
  # Read data and adjust p val
  dat = readRDS(i)
  dat$result$Bonferroni = p.adjust(dat$result$P.Value, method = "bonferroni")
  # perform GO
  input_hyper = data.frame(dat$result$gene_names, is_candidate = ifelse(dat$result$Bonferroni < 0.05,1,0))
  res_hyper = go_enrich(input_hyper, n_randset=1000)
  GO[[length(GO)+1]] = res_hyper[[1]]
}
names(GO) = gsub('Data/DE/|Diff_Exp_Genes_|.rds','',Diff_exp_datasets)

# Format data
df = data.frame(cancer = c(), ontology = c(), name = c(), raw_p = c(), FWER = c())
for (i in 1:length(GO)){
  df = rbind(df, data.frame(cancer = rep(strsplit(names(GO)[i],'_')[[1]][2], nrow(GO[[i]])), 
                            ontology = GO[[i]]$ontology, 
                            name = GO[[i]]$node_name, 
                            raw_p = GO[[i]]$raw_p_overrep, 
                            FWER = GO[[i]]$FWER_overrep))
}

df = subset(df, ontology == 'biological_process')
df = subset(df, FWER < 0.05)

saveRDS(df, 'GO_DE_genes_FWER.rds')


# Differentially Connected Genes 

DC_Genes_datasets = list.files('Data/DC/', '^Diff_Conn_Genes', full.names = T)

GO_DC = list()
for (i in DC_Genes_datasets){
  # Read data and adjust p val
  dat = readRDS(i)
  dat$result$Bonferroni = p.adjust(dat$result$P.Value, method = "bonferroni")
  # perform GO
  input_hyper = data.frame(names(dat$Pval_adj), is_candidate = ifelse(dat$Pval_adj < 0.05,1,0))
  res_hyper = go_enrich(input_hyper, n_randset=1000)
  GO_DC[[length(GO_DC)+1]] = res_hyper[[1]]
}
names(GO_DC) = gsub('.rds','',word(DC_Genes_datasets, -1, sep = '_'))

# Format data
df_DC = data.frame(cancer = c(), ontology = c(), name = c(), raw_p = c(), FWER = c())
for (i in 1:length(GO_DC)){
  df_DC = rbind(df_DC, data.frame(cancer = rep(names(GO_DC)[i], nrow(GO_DC[[i]])), 
                                  ontology = GO_DC[[i]]$ontology, 
                                  name = GO_DC[[i]]$node_name, 
                                  raw_p = GO_DC[[i]]$raw_p_overrep, 
                                  FWER = GO_DC[[i]]$FWER_overrep))
}

df_DC = subset(df_DC, ontology == 'biological_process')
df_DC = subset(df_DC, FWER < 0.05)

saveRDS(df_DC, 'GO_DC_genes_FWER.rds')



## ---- compare cancer type clustering -----


# Get the first three principal components of all pathway impact data
PCA_clust_data = list(prcomp(All_Plot_Data$PA_DE_Metab_PCA[,sapply(All_Plot_Data$PA_DE_Metab_PCA, var) != 0], scale = TRUE)$x[,1:3],
                      prcomp(All_Plot_Data$PA_DC_Metab_PCA[,sapply(All_Plot_Data$PA_DC_Metab_PCA, var) != 0], scale = TRUE)$x[,1:3],
                      prcomp(All_Plot_Data$PA_DE_Genes_PCA[,sapply(All_Plot_Data$PA_DE_Genes_PCA, var) != 0], scale = TRUE)$x[,1:3],
                      prcomp(All_Plot_Data$PA_DC_Genes_PCA[,sapply(All_Plot_Data$PA_DC_Genes_PCA, var) != 0], scale = TRUE)$x[,1:3],
                      prcomp(All_Plot_Data$JPA_DE_PCA[,sapply(All_Plot_Data$JPA_DE_PCA, var) != 0], scale = TRUE)$x[,1:3],
                      prcomp(All_Plot_Data$JPA_DC_PCA[,sapply(All_Plot_Data$JPA_DC_PCA, var) != 0], scale = TRUE)$x[,1:3])

# Create empty matrix
Cancer_clustering_similarity = matrix(1, nrow = 6, ncol = 6)
row.names(Cancer_clustering_similarity) = c('PA DE Metab', 'PA DC Metab', 'PA DE Genes', 'PA DC Genes', 'JPA DE', 'JPA DC')
colnames(Cancer_clustering_similarity) = row.names(Cancer_clustering_similarity)

# Calculate the cophenetic distance between all paired clusterings
for (i in 1:length(PCA_clust_data)){
  for (j in 2:length(PCA_clust_data)){
    # Make the labels the same (take the centroid of duplicate cancer types)
    dat1 = homogonize_rownames(PCA_clust_data[[i]])
    dat2 = homogonize_rownames(PCA_clust_data[[j]])
    
    # Hierarchical Clustering
    dend1 = as.dendrogram(hclust(dist(dat1), "average"))
    dend2 = as.dendrogram(hclust(dist(dat2), "average"))
    
    # Create an intersecting tree
    dend12 = intersect_trees(dend1, dend2)
    
    # Calculate the cophenetic correlation
    Cancer_clustering_similarity[i,j] = cor_cophenetic(dend12)
    Cancer_clustering_similarity[j,i] = cor_cophenetic(dend12)
  }
}

colnames(Cancer_clustering_similarity) = c('Metabolite abundance','Metabolite connectivity','Gene expression','Gene connectivity','Metabolite + gene abundance','Metabolite + gene connectivity')
rownames(Cancer_clustering_similarity) = colnames(Cancer_clustering_similarity) 

# Add to list and save all
All_Plot_Data[[length(All_Plot_Data)+1]] = Cancer_clustering_similarity
names(All_Plot_Data)[length(All_Plot_Data)] = 'Cancer_clustering_similarity'

saveRDS(All_Plot_Data, 'Data/All_Plot_Data.rds')













