# This script creates all figures from the paper

# script containing all functions
source('R Code/R_functions.R')

All_Plot_Data = readRDS('Data/All_Plot_Data.rds')
# Impact plot cutoff. Pathways need to be impacted by at least this amount to be shown in the plot
impact_cutoff = 0.1

## ---- Metabolite plots -----

# > Pathway Analysis -----------
# subset data based on the pathway impact
PA_DC_Metab_sig_imp = subset(All_Plot_Data$PA_DC_Metab_sig, impact >= impact_cutoff)
PA_DE_Metab_sig_imp = subset(All_Plot_Data$PA_DE_Metab_sig, impact >= impact_cutoff)

PA_DC_Metab_sig_imp$impact[PA_DC_Metab_sig_imp$impact >= 1] = 1
PA_DE_Metab_sig_imp$impact[PA_DE_Metab_sig_imp$impact >= 1] = 1

# combine missing pathways from both analyses to make 1 combined plot in the end.
misssing_pathways_DE_metab = setdiff(unique(PA_DC_Metab_sig_imp$pathway), unique(PA_DE_Metab_sig_imp$pathway))
df_sig_DEE_metab = rbind(PA_DE_Metab_sig_imp, data.frame(dataset = rep(NA, length(misssing_pathways_DE_metab)),
                                         cancer_type = rep('Renal', length(misssing_pathways_DE_metab)), 
                                         pathway = misssing_pathways_DE_metab, 
                                         folds = rep(NA, length(misssing_pathways_DE_metab)), 
                                         impact = rep(0, length(misssing_pathways_DE_metab)), 
                                         FDR = rep(NA, length(misssing_pathways_DE_metab)), 
                                         pval = rep(1, length(misssing_pathways_DE_metab)), 
                                         p.adj = rep(NA, length(misssing_pathways_DE_metab)),
                                         p.adj.FWER = rep(NA, length(misssing_pathways_DE_metab))))

misssing_pathways_DC_metab = setdiff(unique(PA_DE_Metab_sig_imp$pathway), unique(PA_DC_Metab_sig_imp))
df_sig_DCC_metab = rbind(PA_DC_Metab_sig_imp, data.frame(dataset = rep(NA, length(misssing_pathways_DC_metab)),
                                      cancer_type = rep('Renal', length(misssing_pathways_DC_metab)), 
                                      pathway = misssing_pathways_DC_metab, 
                                      folds = rep(NA, length(misssing_pathways_DC_metab)), 
                                      impact = rep(0, length(misssing_pathways_DC_metab)), 
                                      FDR = rep(NA, length(misssing_pathways_DC_metab)), 
                                      pval = rep(1, length(misssing_pathways_DC_metab)), 
                                      p.adj = rep(NA, length(misssing_pathways_DC_metab)),
                                      p.adj.FWER = rep(NA, length(misssing_pathways_DC_metab))))

# Fix label names
df_sig_DEE_metab$pathway = factor(df_sig_DEE_metab$pathway, levels = unique(as.character(df_sig_DCC_metab$pathway[order(as.character(df_sig_DCC_metab[,3]) )])))
df_sig_DCC_metab$pathway = factor(df_sig_DCC_metab$pathway, levels = unique(as.character(df_sig_DCC_metab$pathway[order(as.character(df_sig_DCC_metab[,3]) )])))
df_sig_DEE_metab$cancer_type = factor(df_sig_DEE_metab$cancer_type, levels = unique(as.character(df_sig_DCC_metab$cancer_type)))
df_sig_DCC_metab$cancer_type = factor(df_sig_DCC_metab$cancer_type, levels = unique(as.character(df_sig_DCC_metab$cancer_type)))


# Make pathway plots
pw_DE = ggplot(df_sig_DEE_metab, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
  geom_beeswarm(groupOnX = F, alpha = 0.8, dodge.width = 0.1) +
  labs(x = 'Pathway Impact',
       y = '',
       title = '',
       color = 'Cancer Type',
       size =  bquote('-log('*p[adj]*')')) +
  xlim(c(0,1))+
  scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_metab$cancer_type), names(cancer_colors))]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.ticks.y = element_blank(),
        axis.text.y = element_text(size=14, face="plain", colour = "black"),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.position = 'none',
        legend.background = element_blank(),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

pw_DC = ggplot(df_sig_DCC_metab, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
  geom_beeswarm(groupOnX = F, alpha = 0.8, dodge.width = 0.1) +
  labs(x = 'Pathway Impact',
       y = '',
       title = '',
       color = 'Cancer Type',
       size =  bquote('-log('*p[adj]*')')) +
  xlim(c(0,1))+
  scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_metab$cancer_type), names(cancer_colors))]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.ticks.y = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.position = 'none',
        legend.background = element_blank(),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

legend_pw <- get_legend(
  ggplot(df_sig_DCC_metab, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
    geom_beeswarm(groupOnX = F, alpha = 0.8) + 
    labs(color = 'Cancer Type', size = bquote('-log('*p[adj]*')') )+
    scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_metab$cancer_type), names(cancer_colors))]) +
    theme(legend.key = element_blank(),
          legend.title = element_text(size = 14),
          legend.text = element_text(size = 14),
          legend.background = element_blank()))




# > PCA ------------------------



DE_PCA = PCA_biplot2(All_Plot_Data$PA_DE_Metab_PCA,
                     title = "",
                     alternative_ind_name = c('Liver (U)', 'Lung (T)', 'Colorectal (S)', 'Breast (P)', 'Breast (S)'),
                     avoid_label =  names(All_Plot_Data$PA_DE_Metab_PCA)[!names(All_Plot_Data$PA_DE_Metab_PCA) %in% unique(as.character(subset(All_Plot_Data$PA_DE_Metab_sig, impact > 0.25)$pathway))]
)

DC_PCA = PCA_biplot2(All_Plot_Data$PA_DC_Metab_PCA, 
                     title = "",
                     alternative_ind_name = c('Renal (U)', 'Liver (S)', 'Liver (U)', 'Breast (P)', 'Breast (T)', 'Colorectal (S)', 'Breast (P)', 'Lung (T)', 'Lung (P)'),
                     avoid_label =  names(All_Plot_Data$PA_DC_Metab_PCA)[!names(All_Plot_Data$PA_DC_Metab_PCA) %in% unique(as.character(subset(All_Plot_Data$PA_DC_Metab_sig, impact > 0.25)$pathway))]
)

DE_PCA = DE_PCA + theme(legend.position = 'none',
                        legend.key = element_blank(),
                        legend.background = element_blank())

DC_PCA = DC_PCA + theme(legend.position = c(0.9,0.2),
                        legend.key = element_blank(),
                        legend.background = element_blank())



# > Network PCA and ROC --------------------------------------



alt_names_metab_net_pca = gsub('cancer', 'Ca', gsub('control', 'Co', gsub('Urine', '(U)', gsub('Serum', '(S)', gsub('Tissue', '(T)', gsub('Plasma', '(P)',gsub(' Adenocarcinoma', '', gsub('Myeloma', 'myeloma', 
do.call('paste', list(strsplit2(row.names(All_Plot_Data$Network_Stats_Metab), ' ')[,1], 
                      strsplit2(row.names(All_Plot_Data$Network_Stats_Metab), ' ')[,3],
                      strsplit2(row.names(All_Plot_Data$Network_Stats_Metab), ' ')[,4],
                      strsplit2(row.names(All_Plot_Data$Network_Stats_Metab), ' ')[,5])) ))))))))

# calculate eigenvectors and find the %of variation + cos2
pca <- prcomp(All_Plot_Data$Network_Stats_Metab, scale = TRUE)
scree = fviz_eig(pca)
var <- facto_summarize(pca, element = "var", result = c("coord", "cos2"), axes = c(1, 2))
ind <- facto_summarize(pca, element = "ind", result = c("coord", "cos2"), axes = c(1, 2))
colnames(var)[2:3] <- c("x", "y")
colnames(ind)[2:3] <- c("x", "y")

# Scale Loadings 
r <- min((max(ind[, "x"]) - min(ind[, "x"])/(max(var[, "x"]) - 
                                               min(var[, "x"]))), (max(ind[, "y"]) - min(ind[, "y"])/(max(var[, 
                                                                                                              "y"]) - min(var[, "y"]))))
var[, c("x", "y")] <- var[, c("x", "y")] * r * 0.7

# Merge the indivduals (eigenvectors) and variables (loading rotations, now scaled), match colors to cancer type
var$type = rep('var', nrow(var))
ind$type = rep('idn', nrow(ind))
bi = rbind(ind, var)
bi$cos2[bi$type == 'idn'] = 0
bi$name = as.character(bi$name)
bi$name[bi$type == 'idn'] = alt_names_metab_net_pca
bi$hexcols = cancer_colors[match(strsplit2(bi$name, ' ')[,2], names(cancer_colors))]
bi$hexcols[grepl('Multiple myeloma', bi$name)] = "#7E6148FF"
bi$hexcols[is.na(bi$hexcols)] = '#000000'

# Make PCA plot
PCA_Network_Metab = ggplot(bi, aes(x = x, y =y)) +
                      geom_point(aes(x, y), color = bi$hexcols, alpha = ifelse(bi$type == 'idn', 1, 0)) +
                      geom_text_repel(aes(label = name), color = bi$hexcols, size = ifelse(bi$type == 'idn', 4.5, 3.5), segment.size = 0.25, max.iter = 2500, force = 0.2, nudge_y = 0,
                                      fontface="plain", alpha = ifelse(bi$type == 'idn', 1, 0.5)) +
                      geom_segment(aes(x = 0, y = 0, xend = x, yend = y),
                                   arrow = arrow(length = unit(0.2,"cm"))
                                   , alpha = ifelse(bi$type == 'var', 0.5, 0)) +
                      geom_hline(yintercept = 0, linetype = 'dashed', alpha = 0.25) +
                      geom_vline(xintercept = 0, linetype = 'dashed', alpha = 0.25) +
                      guides(alpha = FALSE) +
                      labs(x = paste0('PC1', ' (',round(scree$data$eig[1],1),'%)'),
                           y = paste0('PC2', ' (',round(scree$data$eig[2],1),'%)'),
                           title = '') +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        axis.text.y = element_text(size=16, face="bold", colour = "black"),
        axis.title.y = element_text(size=14, face="plain", colour = "black"),
        legend.title = element_text(size=14, face="bold", colour = "black"),
        legend.text = element_text(size=14, face="plain", colour = "black"),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

# Make ROC plot
All_Plot_Data$ROC_Metab$measure = gsub('Distance', 'Dist.', All_Plot_Data$ROC_Metab$measure) 
ROC_plot_Metab = ggplot(All_Plot_Data$ROC_Metab)+
  geom_path(aes(x = specificities, y = sensitivities, color = factor(measure)), alpha = 0.8, size = 1) +
  coord_cartesian(xlim = c(1, 0), ylim = c(0, 1), expand = F) +
  geom_abline(intercept = 1, slope = -1, linetype = 'dashed') +
  labs(x = 'Specificity', y = 'Sensitivity',
       title = '',
       color = '       Topological Measure') +
  scale_color_manual(values=cols[c(1:4,8,6,7,5,9:12)]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5, size=12, face="bold", colour = "black"),
        axis.ticks.y = element_blank(),
        axis.text.y = element_text(size=16, face="bold", colour = "black"),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.y = element_text(size=14, face="plain", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.text = element_text(size=12, face="plain", colour = "black"),
        legend.title = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.background = element_blank(),
        legend.position = c(0.75, 0.28),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))


# Add plots to one figure and save
pw_p_grid_Metab = plot_grid(pw_DE, pw_DC, labels = c('A', 'B'), rel_widths = c(1,0.475), label_size = 20)
Pathway_Plot_Metab = plot_grid(pw_p_grid_Metab, legend_pw, nrow = 1, rel_widths = c(1, 0.1), label_size = 20)
Pathway_Plot_Metab
dev.print(pdf, 'Results/Figure_1.pdf' , width = 14, height = 10)

# Add plots to one figure and save
PCA_p_grid_Metab = plot_grid(DE_PCA, DC_PCA, labels = c('A', 'B'), label_size = 20)
PCA_plot_grid_Metab = plot_grid(PCA_p_grid_Metab, nrow = 1, label_size = 20)
Network_plot_grid_Metab = plot_grid(PCA_Network_Metab, ROC_plot_Metab, labels = c('C', 'D'), nrow = 1, label_size = 20)
plot_grid(PCA_plot_grid_Metab,Network_plot_grid_Metab, ncol = 1, rel_heights = c(1,1), label_size = 20)
dev.print(pdf, 'Results/Figure_2.pdf' , width = 14, height = 14)



# ----- Gene plots --------------------------------------

# > Pathway Analysis ----
# subset data based on the impact
PA_DC_Genes_sig_imp = subset(All_Plot_Data$PA_DC_Genes_sig, impact >= impact_cutoff)
PA_DE_Genes_sig_imp = subset(All_Plot_Data$PA_DE_Genes_sig, impact >= impact_cutoff)

# Manual fix of one pathway name to prevent one very long label
PA_DC_Genes_sig_imp$pathway = gsub(' - lacto and neolacto series','', PA_DC_Genes_sig_imp$pathway)
PA_DE_Genes_sig_imp$pathway = gsub(' - lacto and neolacto series','', PA_DE_Genes_sig_imp$pathway)

PA_DC_Genes_sig_imp$impact[PA_DC_Genes_sig_imp$impact >= 1] = 1
PA_DE_Genes_sig_imp$impact[PA_DE_Genes_sig_imp$impact >= 1] = 1

# combine missing pathways from both analyses to make 1 combined plot in the end.
misssing_pathways_DE_Genes = setdiff(unique(PA_DC_Genes_sig_imp$pathway), unique(PA_DE_Genes_sig_imp$pathway))
df_sig_DEE_Genes = rbind(PA_DE_Genes_sig_imp, data.frame(dataset = rep(NA, length(misssing_pathways_DE_Genes)),
                                                                   cancer_type = rep('Renal', length(misssing_pathways_DE_Genes)), 
                                                                   pathway = misssing_pathways_DE_Genes, 
                                                                   folds = rep(NA, length(misssing_pathways_DE_Genes)), 
                                                                   impact = rep(0, length(misssing_pathways_DE_Genes)), 
                                                                   FDR = rep(NA, length(misssing_pathways_DE_Genes)), 
                                                                   pval = rep(1, length(misssing_pathways_DE_Genes)), 
                                                                   p.adj = rep(NA, length(misssing_pathways_DE_Genes)),
                                                                   p.adj.FWER = rep(NA, length(misssing_pathways_DE_Genes))))

misssing_pathways_DC_Genes = setdiff(unique(PA_DE_Genes_sig_imp$pathway), unique(PA_DC_Genes_sig_imp))
df_sig_DCC_Genes = rbind(PA_DC_Genes_sig_imp, data.frame(dataset = rep(NA, length(misssing_pathways_DC_Genes)),
                                                                   cancer_type = c(rep('Renal', length(misssing_pathways_DC_Genes)-3), 'Lung', 'Breast', 'Colorectal'), 
                                                                   pathway = misssing_pathways_DC_Genes, 
                                                                   folds = rep(NA, length(misssing_pathways_DC_Genes)), 
                                                                   impact = rep(0, length(misssing_pathways_DC_Genes)), 
                                                                   FDR = rep(NA, length(misssing_pathways_DC_Genes)), 
                                                                   pval = rep(1, length(misssing_pathways_DC_Genes)), 
                                                                   p.adj = rep(NA, length(misssing_pathways_DC_Genes)),
                                                                   p.adj.FWER = rep(NA, length(misssing_pathways_DC_Genes))))

# Fix label names
df_sig_DEE_Genes$pathway = factor(df_sig_DEE_Genes$pathway, levels = unique(as.character(df_sig_DCC_Genes$pathway[order(as.character(df_sig_DCC_Genes[,3]) )])))
df_sig_DCC_Genes$pathway = factor(df_sig_DCC_Genes$pathway, levels = unique(as.character(df_sig_DCC_Genes$pathway[order(as.character(df_sig_DCC_Genes[,3]) )])))
df_sig_DEE_Genes$cancer_type = factor(df_sig_DEE_Genes$cancer_type, levels = unique(as.character(df_sig_DCC_Genes$cancer_type)))
df_sig_DCC_Genes$cancer_type = factor(df_sig_DCC_Genes$cancer_type, levels = unique(as.character(df_sig_DCC_Genes$cancer_type)))

# Make pathway impact plots
pw_DE_Genes = ggplot(df_sig_DEE_Genes, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
  geom_beeswarm(groupOnX = F, alpha = 0.8, dodge.width = 0.1) +
  labs(x = 'Pathway Impact',
       y = '',
       title = '',
       color = 'Cancer Type',
       size =  bquote('-log('*p[adj]*')')) +
  xlim(c(0,1))+
  scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_Genes$cancer_type), names(cancer_colors))]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.ticks.y = element_blank(),
        axis.text.y = element_text(size=14, face="plain", colour = "black"),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.position = 'none',
        legend.background = element_blank(),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95")
  )

pw_DC_Genes = ggplot(df_sig_DCC_Genes, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
  geom_beeswarm(groupOnX = F, alpha = 0.8, dodge.width = 0.1) +
  labs(x = 'Pathway Impact',
       y = '',
       title = '',
       color = 'Cancer Type',
       size =  bquote('-log('*p[adj]*')')) +
  xlim(c(0,1))+
  scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_Genes$cancer_type), names(cancer_colors))]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.ticks.y = element_blank(),
        axis.text.y =  element_blank(),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.position = 'none',
        legend.background = element_blank(),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

legend_pw_Genes <- get_legend(
  ggplot(df_sig_DCC_Genes, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
    geom_beeswarm(groupOnX = F, alpha = 0.8) + 
    labs(color = 'Cancer Type', size = bquote('-log('*p[adj]*')') )+
    scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_Genes$cancer_type), names(cancer_colors))]) +
    theme(legend.key = element_blank(),
          legend.title = element_text(size = 14),
          legend.text = element_text(size = 14),
          legend.background = element_blank()))



# > PCA --------------------



DE_PCA_Genes = PCA_biplot2(All_Plot_Data$PA_DE_Genes_PCA,
                     title = "",
                     avoid_label = names(All_Plot_Data$PA_DE_Genes_PCA)[!names(All_Plot_Data$PA_DE_Genes_PCA) %in% unique(as.character(subset(All_Plot_Data$PA_DE_Genes_sig, impact > 0.25)$pathway))]
)

DC_PCA_Genes = PCA_biplot2(All_Plot_Data$PA_DC_Genes_PCA[,sapply(All_Plot_Data$PA_DC_Genes_PCA, var) != 0], 
                     title = "",
                     avoid_label = names(All_Plot_Data$PA_DC_Genes_PCA)[!names(All_Plot_Data$PA_DC_Genes_PCA) %in% unique(as.character(subset(All_Plot_Data$PA_DC_Genes_sig, impact > 0.25)$pathway))]
)

DE_PCA_Genes = DE_PCA_Genes + theme(legend.position = 'none',
                        legend.key = element_blank(),
                        legend.background = element_blank())

DC_PCA_Genes = DC_PCA_Genes + theme(legend.position = c(0.9,0.2),
                        legend.key = element_blank(),
                        legend.background = element_blank())


# > Network PCA and ROC --------------------------------------

alt_names_metab_net_pca_Genes = gsub('renal', 'Renal', gsub('gastric', 'Gastric', gsub('prostate', 'Prostate', gsub('liver', 'Liver', gsub('Myeloma', 'myeloma', gsub('cancer', 'Ca', gsub('control', 'Co',row.names(All_Plot_Data$Network_Stats_Genes))))))))

# calculate eigenvectors and find the %of variation + cos2
pca <- prcomp(All_Plot_Data$Network_Stats_Genes[,sapply(All_Plot_Data$Network_Stats_Genes, var) != 0], scale = TRUE)
scree = fviz_eig(pca)
var <- facto_summarize(pca, element = "var", result = c("coord", "cos2"), axes = c(1, 2))
ind <- facto_summarize(pca, element = "ind", result = c("coord", "cos2"), axes = c(1, 2))
colnames(var)[2:3] <- c("x", "y")
colnames(ind)[2:3] <- c("x", "y")

# Scale Loadings 
r <- min((max(ind[, "x"]) - min(ind[, "x"])/(max(var[, "x"]) - 
                                               min(var[, "x"]))), (max(ind[, "y"]) - min(ind[, "y"])/(max(var[, 
                                                                                                              "y"]) - min(var[, "y"]))))
var[, c("x", "y")] <- var[, c("x", "y")] * r * 0.7

# Merge the indivduals (eigenvectors) and variables (loading rotations, now scaled), match colors to cancer type
var$type = rep('var', nrow(var))
ind$type = rep('idn', nrow(ind))
bi = rbind(ind, var)
bi$cos2[bi$type == 'idn'] = 0
bi$name = as.character(bi$name)
bi$name[bi$type == 'idn'] = alt_names_metab_net_pca_Genes
bi$hexcols = cancer_colors[match(strsplit2(bi$name, ' ')[,2], names(cancer_colors))]
bi$hexcols[grepl('Multiple myeloma', bi$name)] = "#7E6148FF"
bi$hexcols[is.na(bi$hexcols)] = '#000000'

# Make PCA plot
PCA_Network_Genes = ggplot(bi, aes(x = x, y =y)) +
  geom_point(aes(x, y), color = bi$hexcols, alpha = ifelse(bi$type == 'idn', 1, 0)) +
  geom_text_repel(aes(label = name), color = bi$hexcols, size = ifelse(bi$type == 'idn', 4.5, 3.5), segment.size = 0.25, max.iter = 2500, force = 0.2, nudge_y = 0,
                  fontface="plain", alpha = ifelse(bi$type == 'idn', 1, 0.5)) +
  geom_segment(aes(x = 0, y = 0, xend = x, yend = y),
               arrow = arrow(length = unit(0.2,"cm"))
               , alpha = ifelse(bi$type == 'var', 0.5, 0)) +
  geom_hline(yintercept = 0, linetype = 'dashed', alpha = 0.25) +
  geom_vline(xintercept = 0, linetype = 'dashed', alpha = 0.25) +
  guides(alpha = FALSE) +
  labs(x = paste0('PC1', ' (',round(scree$data$eig[1],1),'%)'),
       y = paste0('PC2', ' (',round(scree$data$eig[2],1),'%)'),
       title = '',
       color = bquote('cos'^2)) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        axis.text.y = element_text(size=16, face="bold", colour = "black"),
        axis.title.y = element_text(size=14, face="plain", colour = "black"),
        legend.title = element_text(size=14, face="bold", colour = "black"),
        legend.text = element_text(size=14, face="plain", colour = "black"),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

# Make ROC plot
All_Plot_Data$ROC_Genes$measure = gsub('Distance', 'Dist.', All_Plot_Data$ROC_Genes$measure) 
ROC_plot_Genes = ggplot(All_Plot_Data$ROC_Genes)+
  geom_path(aes(x = specificities, y = sensitivities, color = factor(measure)), size = 1, alpha = 0.8) +
  coord_cartesian(xlim = c(1, 0), ylim = c(0, 1), expand = F) +
  geom_abline(intercept = 1, slope = -1, linetype = 'dashed') +
  labs(x = 'Specificity', y = 'Sensitivity',
       title = '',
       color = '       Topological Measure') +
  scale_color_manual(values=cols[c(1:4,8,6,7,5,9:12)]) +
  theme(panel.border = element_rect(colour = "black",size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5, size=12, face="bold", colour = "black"),
        axis.ticks.y = element_blank(),
        axis.text.y = element_text(size=16, face="bold", colour = "black"),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.y = element_text(size=14, face="plain", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.text = element_text(size=12, face="plain", colour = "black"),
        legend.title = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.background = element_blank(),
        legend.position = c(0.75, 0.28),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

# Add plots to one figure and save plot
pw_p_grid_Genes = plot_grid(pw_DE_Genes, pw_DC_Genes, labels = c('A', 'B'), rel_widths = c(1,0.5), label_size = 20)
Pathway_Plot_Genes = plot_grid(pw_p_grid_Genes, legend_pw_Genes, nrow = 1, rel_widths = c(1, 0.16), label_size = 20)
Pathway_Plot_Genes
dev.print(pdf, 'Results/Figure_3.pdf' , width = 14, height = 10)

# Add plots to one figure and save plots
PCA_p_grid_Genes = plot_grid(DE_PCA_Genes, DC_PCA_Genes, labels = c('A', 'B'), label_size = 20)
PCA_plot_grid_Genes = plot_grid(PCA_p_grid_Genes, nrow = 1, label_size = 20)
Network_plot_grid_Genes= plot_grid(PCA_Network_Genes, ROC_plot_Genes, labels = c('C', 'D'), nrow = 1, label_size = 20)
plot_grid( PCA_plot_grid_Genes,Network_plot_grid_Genes, ncol = 1, rel_heights = c(1,1), label_size = 20)
dev.print(pdf, 'Results/Figure_4.pdf' , width = 14, height = 14)



## ---- Joint Pathway Plots ----
# Subset data based on the impact
JPA_DC_sig_imp = subset(All_Plot_Data$JPA_DC_sig, impact >= impact_cutoff)
JPA_DE_sig_imp = subset(All_Plot_Data$JPA_DE_sig, impact >= impact_cutoff)

JPA_DC_sig_imp$impact[JPA_DC_sig_imp$impact >= 1] = 1
JPA_DE_sig_imp$impact[JPA_DE_sig_imp$impact >= 1] = 1

# > Pathway Analysis ----

# combine missing pathways from both analyses to make 1 combined plot in the end.
misssing_pathways_DE_Joint = setdiff(unique(JPA_DC_sig_imp$pathway), unique(JPA_DE_sig_imp$pathway))
df_sig_DEE_Joint = rbind(JPA_DE_sig_imp, data.frame(dataset = rep(NA, length(misssing_pathways_DE_Joint)),
                                                                   cancer_type = rep('Renal', length(misssing_pathways_DE_Joint)), 
                                                                   pathway = misssing_pathways_DE_Joint, 
                                                                   folds = rep(NA, length(misssing_pathways_DE_Joint)), 
                                                                   impact = rep(0, length(misssing_pathways_DE_Joint)), 
                                                                   FDR = rep(NA, length(misssing_pathways_DE_Joint)), 
                                                                   pval = rep(1, length(misssing_pathways_DE_Joint)), 
                                                                   p.adj = rep(NA, length(misssing_pathways_DE_Joint)),
                                                                   p.adj.FWER = rep(NA, length(misssing_pathways_DE_Joint))))

misssing_pathways_DC_Joint = setdiff(unique(JPA_DE_sig_imp$pathway), unique(JPA_DC_sig_imp$pathway))
df_sig_DCC_Joint = rbind(JPA_DC_sig_imp, data.frame(dataset = rep(NA, length(misssing_pathways_DC_Joint)),
                                                                   cancer_type = rep('Renal', length(misssing_pathways_DC_Joint)), 
                                                                   pathway = misssing_pathways_DC_Joint, 
                                                                   folds = rep(NA, length(misssing_pathways_DC_Joint)), 
                                                                   impact = rep(0, length(misssing_pathways_DC_Joint)), 
                                                                   FDR = rep(NA, length(misssing_pathways_DC_Joint)), 
                                                                   pval = rep(1, length(misssing_pathways_DC_Joint)), 
                                                                   p.adj = rep(NA, length(misssing_pathways_DC_Joint)),
                                                                   p.adj.FWER = rep(NA, length(misssing_pathways_DC_Joint))))


# Fix label names
df_sig_DEE_Joint$pathway = factor(df_sig_DEE_Joint$pathway, levels = unique(as.character(df_sig_DCC_Joint$pathway[order(as.character(df_sig_DCC_Joint[,3]) )])))
df_sig_DCC_Joint$pathway = factor(df_sig_DCC_Joint$pathway, levels = unique(as.character(df_sig_DCC_Joint$pathway[order(as.character(df_sig_DCC_Joint[,3]) )])))
df_sig_DEE_Joint$cancer_type = factor(df_sig_DEE_Joint$cancer_type, levels = unique(as.character(df_sig_DCC_Joint$cancer_type)))
df_sig_DCC_Joint$cancer_type = factor(df_sig_DCC_Joint$cancer_type, levels = unique(as.character(df_sig_DCC_Joint$cancer_type)))




pw_DE_Joint = ggplot(df_sig_DEE_Joint, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
  geom_beeswarm(groupOnX = F, alpha = 0.8, dodge.width = 0.1) +
  labs(x = 'Pathway Impact',
       y = '',
       title = '',
       color = 'Cancer Type',
       size =  bquote('-log('*p[adj]*')')) +
  xlim(c(0,1))+
  scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_Joint$cancer_type), names(cancer_colors))]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.ticks.y = element_blank(),
        axis.text.y = element_text(size=16, face="plain", colour = "black"),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.position = 'none',
        legend.background = element_blank(),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95")
  )

pw_DC_Joint = ggplot(df_sig_DCC_Joint, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
  geom_beeswarm(groupOnX = F, alpha = 0.8, dodge.width = 0.1) +
  labs(x = 'Pathway Impact',
       y = '',
       title = '',
       color = 'Cancer Type',
       size =  bquote('-log('*p[adj]*')')) +
  xlim(c(0,1))+
  scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_Joint$cancer_type), names(cancer_colors))]) +
  theme(panel.border = element_rect(colour = "black", size = 1, fill = NA),
        panel.background = element_blank(),
        plot.title = element_text(hjust = 0.5),
        axis.ticks.y = element_blank(),
        axis.text.y =  element_blank(),
        axis.text.x = element_text(size=16, face="bold", colour = "black"),
        axis.title.x = element_text(size=14, face="plain", colour = "black"),
        legend.key = element_blank(),
        legend.position = 'none',
        legend.background = element_blank(),
        panel.grid.major = element_line(colour = "grey95"),
        panel.grid.minor = element_line(colour = "grey95"))

legend_pw_Joint <- get_legend(
  ggplot(df_sig_DCC_Joint, aes(y=pathway,x=impact, color=cancer_type, size = -log(p.adj)))+
    geom_beeswarm(groupOnX = F, alpha = 0.8) + 
    labs(color = 'Cancer Type', size = bquote('-log('*p[adj]*')') )+
    scale_color_manual(values=cancer_colors[match(levels(df_sig_DCC_Joint$cancer_type), names(cancer_colors))]) +
    theme(legend.key = element_blank(),
          legend.title = element_text(size = 14),
          legend.text = element_text(size = 14),
          legend.background = element_blank()))



# > PCA --------------------

DE_PCA_Joint = PCA_biplot2(All_Plot_Data$JPA_DE_PCA,
                           title = "",
                           variable_alpha = 0.1,
                           alternative_ind_name = c('Liver (S)', 'Liver (U)', 'Lung (T)', 'Breast (P)', 'Multiple myeloma', 'Colorectal (S)', 'Breast (P)', 'Breast (S)'),
                           avoid_label = names(All_Plot_Data$JPA_DE_PCA)[!names(All_Plot_Data$JPA_DE_PCA) %in% unique(as.character(subset(All_Plot_Data$JPA_DE_sig, impact > 0.25)$pathway))])

DC_PCA_Joint = PCA_biplot2(All_Plot_Data$JPA_DC_PCA[,sapply(All_Plot_Data$JPA_DC_PCA, var) != 0], 
                           title = "",
                           variable_alpha = 0.1,
                           alternative_ind_name = gsub('Urine', '(U)', gsub('Tissue', '(T)',gsub('Serum', '(S)', gsub('Plasma', '(P)', gsub('myeloma', 'myeloma (T)', word(rownames(All_Plot_Data$JPA_DC_PCA), 1,-2)))))),
                           avoid_label = names(All_Plot_Data$JPA_DC_PCA)[!names(All_Plot_Data$JPA_DC_PCA) %in% unique(as.character(subset(All_Plot_Data$JPA_DC_sig, impact > 0.25)$pathway))])

DE_PCA_Joint = DE_PCA_Joint + theme(legend.position = 'none',
                                    legend.key = element_blank(),
                                    legend.background = element_blank())

DC_PCA_Joint = DC_PCA_Joint + theme(legend.position = c(0.9,0.2),
                                    legend.key = element_blank(),
                                    legend.background = element_blank())



# Add all plots to one figure
pw_p_grid_Joint = plot_grid(pw_DE_Joint, pw_DC_Joint, labels = c('A', 'B'), rel_widths = c(1,0.45), label_size = 20)
Pathway_Plot_Joint = plot_grid(pw_p_grid_Joint, legend_pw_Joint, nrow = 1, rel_widths = c(1, 0.16), label_size = 20)
PCA_p_grid_Joint = plot_grid(DE_PCA_Joint, DC_PCA_Joint, labels = c('C', 'D'), label_size = 20)

plot_grid(Pathway_Plot_Joint, PCA_p_grid_Joint, ncol = 1, rel_heights = c(1,0.65), label_size = 20)
dev.print(pdf, 'Figure_5.pdf' , width = 14, height = 18)



## ---- Correlation plot --------------------



corrplot(All_Plot_Data$Cancer_clustering_similarity,
         p.mat = All_Plot_Data$Cancer_clustering_similarity,
         sig.level = -1,
         insig = "p-value",
         order = "hclust",
         method = "circle", type = "upper",
         pch.cex = .9,
         pch.col = "white", tl.col = "black", tl.srt = 45)

dev.print(pdf, 'Cancer_Type_Clustering.pdf', width = 10, height = 10)



## ---- Hierarchical clustering ----


# Change row names to distinguish between different analysis methods
row.names(All_Plot_Data$PA_DE_Metab_PCA) = paste(row.names(All_Plot_Data$PA_DE_Metab_PCA), 'DE_Metab') 
row.names(All_Plot_Data$PA_DC_Metab_PCA) = paste(row.names(All_Plot_Data$PA_DC_Metab_PCA), 'DC_Metab') 
row.names(All_Plot_Data$PA_DE_Genes_PCA) = paste(row.names(All_Plot_Data$PA_DE_Genes_PCA), 'DE_Genes') 
row.names(All_Plot_Data$PA_DC_Genes_PCA) = paste(row.names(All_Plot_Data$PA_DC_Genes_PCA), 'DC_Genes') 
row.names(All_Plot_Data$JPA_DE_PCA) = paste(row.names(All_Plot_Data$JPA_DE_PCA), 'DE_Joint') 
row.names(All_Plot_Data$JPA_DC_PCA) = paste(row.names(All_Plot_Data$JPA_DC_PCA), 'DC_Joint') 

### indv dends
dend1_DE_Metab = ggdend_from_df(All_Plot_Data$PA_DE_Metab_PCA)
dend2_DC_Metab = ggdend_from_df(All_Plot_Data$PA_DC_Metab_PCA)
dend3_DE_Genes = ggdend_from_df(All_Plot_Data$PA_DE_Genes_PCA)
dend4_DC_Genes = ggdend_from_df(All_Plot_Data$PA_DC_Genes_PCA)
dend5_DE_Joint = ggdend_from_df(All_Plot_Data$JPA_DE_PCA)
dend6_DC_Joint = ggdend_from_df(All_Plot_Data$JPA_DC_PCA)
# Network dends
dend7_Net_Metab = ggdend_from_df(All_Plot_Data$Network_Stats_Metab, xtitle = 'Distance')
dend8_Net_Genes = ggdend_from_df(All_Plot_Data$Network_Stats_Genes, xtitle = 'Distance')
# Add all to one figure
plot_grid(dend1_DE_Metab, dend2_DC_Metab, 
          dend3_DE_Genes, dend4_DC_Genes, 
          dend5_DE_Joint, dend6_DC_Joint, 
          dend7_Net_Metab,dend8_Net_Genes,  
          nrow = 4, ncol = 2, labels = c('A','B','C','D','E','F','G','H'), label_size = 20, rel_heights = c(0.6,0.6,0.6,1.5))

dev.print(pdf, 'Figure_6.pdf', width = 10, height = 18)

